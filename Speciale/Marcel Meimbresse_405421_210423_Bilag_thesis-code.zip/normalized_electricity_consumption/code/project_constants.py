
INTERESTING_PARAMS = ["wind_speed_past1h", "temp_mean_past1h", "humidity_past1h", "precip_past1h", "radia_glob_past1h",
                      "sun_last1h_glob", "temp_grass_mean_past1h", "temp_soil_mean_past1h", "leav_hum_dur_past1h",
                      "pressure", "visibility"]     # , "snow_depth_man"]

ACCUMULATIVE_PARAMS = ["sun_last1h_glob", "leav_hum_dur_past1h"]

# [Data Unit Description](https://confluence.govcloud.dk/pages/viewpage.action?pageId=26476616)
DATA_FOLDER = "../data/"
WEATHER_DATA_FOLDER = DATA_FOLDER + "dmi_obs/"
RESULT_FOLDER = "../results/"
PLOT_FOLDER = "../notes/plots/"
DMI_FILE = DATA_FOLDER + "dmi_data.csv"
EL_CONSUMP_FILE = DATA_FOLDER + "energinet_market_data.csv"
INCLUDE_BOILER_CONSUMPTION = False
DENSELY_DASHED = (0, (5, 1))
RESOLUTION_TO_LETTER = {"daily": "D", "weekly": "W", "monthly": "M"}
ZONE_TO_REGIONS = {"DK1": ["Region Syddanmark", "Region Midtjylland", "Region Nordjylland"],
                   "DK2": ["Region Sjælland", "Region Hovedstaden"]}

ARIMA_DK1_BEST = ([4, 0, 0], [5, 1, 0, 12])
ARIMA_DK2_BEST = ([0, 0, 0], [2, 1, 1, 12])

TRAIN_SIZE = 0.8  # training set size (80%)
