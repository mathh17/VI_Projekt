from pyspark.sql import SparkSession
import os
import zipfile as zipf
import pandas as pd
from tqdm import tqdm
from datetime import timezone
from project_constants import INTERESTING_PARAMS, DATA_FOLDER, WEATHER_DATA_FOLDER

java8_location = '/Library/Java/JavaVirtualMachines/jdk1.8.0_131.jdk/Contents/Home'
os.environ['JAVA_HOME'] = java8_location        # get pyspark working


def unzip(filename):
    f = zipf.ZipFile(filename, "r")
    f.extractall()


def create_spark_session():
    spark = SparkSession.builder \
        .master("local") \
        .appName("DMI Data Extraction") \
        .config("spark.executor.memory", "8G") \
        .config("spark.driver.memory", "8G") \
        .getOrCreate()
    return spark


def remove_id_column(dmi_file, target_file):
    with open(target_file, "w") as target_f:
        with open(dmi_file, "r") as source_f:
            for line in source_f:
                parts = line.split(",")
                filt_parts = parts[1:]
                new_line = ",".join(filt_parts)
                target_f.write(new_line)


# Resample parameters that are sampled at a high time resolution. Average them over 1 hours to fit the other params
def average_params_to_1hour(source_file, target_file):  
    cols = ['parameterId', 'stationId', 'timeObserved', 'value']
    header = ",".join(cols) + "\n"

    def read_param_save_to_disk(param):
        with open(source_file, "r") as source_f:
            temp_header = source_f.readline()
            lines = []
            for line in tqdm(source_f, param):
                if param in line:
                    lines.append(line)
            with open("temp_lines.csv", "w") as temp_f:
                temp_f.write(temp_header)
                temp_f.writelines(lines)
                del lines
    with open(target_file, "w") as target_f:
        target_f.write(header)
    high_res_params = [param for param in INTERESTING_PARAMS if "1h" not in param]
    other_params = [param for param in INTERESTING_PARAMS if param not in high_res_params]
    for param in high_res_params:
        read_param_save_to_disk(param)
        param_df = pd.read_csv("temp_lines.csv")
        param_df['time'] = pd.to_datetime(param_df['timeObserved'], unit='us')
        param_df.drop(columns=["timeCreated", "timeObserved"], inplace=True)
        df_averaged = param_df.groupby("stationId").apply(lambda x: x.resample("H", on="time").value.mean().dropna().reset_index())
        df_averaged.reset_index(level=0, inplace=True)
        df_averaged["parameterId"] = param
        df_averaged["timeObserved"] = df_averaged.time.apply(lambda x: int(x.replace(tzinfo=timezone.utc).timestamp() * 1000000))
        df_averaged.drop(columns="time", inplace=True)
        df_averaged = df_averaged[cols]
        df_averaged.to_csv(target_file, mode='a', header=False, index=False)
    for param in other_params:
        read_param_save_to_disk(param)
        param_df = pd.read_csv("temp_lines.csv")
        param_df.drop(columns="timeCreated", inplace=True)
        param_df = param_df[cols]
        param_df.to_csv(target_file, mode='a', header=False, index=False)
    os.remove("temp_lines.csv")


def remove_station_duplicate_dates(dmi_df_, verbose=False):

    def remove_station_duplicates(station_df):
        return station_df.groupby(["timeObserved", "parameterId"]).mean().reset_index()

    df_list = []
    for param in INTERESTING_PARAMS:
        df_param = dmi_df_[dmi_df_.parameterId == param]
        df_no_duplicates = df_param.groupby("stationId").apply(remove_station_duplicates).reset_index(level=0)
        df_list.append(df_no_duplicates)
    res_df = pd.concat(df_list)
    if verbose:
        print("Removed {} duplicate time stamps".format(len(dmi_df_) - len(res_df)))
    return res_df


# Extract all relevant DMI data from start_year to the end_year and combine in one csv on disk:
def read_weather_data(dmi_folder, target_file, start_year, end_year):
    spark = create_spark_session()
    write_header = True
    for year in range(start_year, end_year):
        for month in range(1, 13):
            try:
                unzip(dmi_folder + "{}-{:02d}.zip".format(year, month))
            except FileNotFoundError:
                print("File not found for year {}, month {:02d}".format(year, month))
                break
            spark_df_curr = spark.read.json("{}-{:02d}.txt".format(year, month))
            df_curr_filtered = spark_df_curr.filter(spark_df_curr.parameterId.isin(INTERESTING_PARAMS))
            filtered_pandas = df_curr_filtered.toPandas()
            filtered_pandas.drop(columns="_id", inplace=True)
            filtered_pandas.drop_duplicates(inplace=True)
            filtered_pandas = remove_station_duplicate_dates(filtered_pandas)
            filtered_pandas.to_csv(DATA_FOLDER + f"{target_file}.csv", mode='a', header=write_header, index=False)
            write_header = False
            del filtered_pandas
            os.remove("{}-{:02d}.txt".format(year, month))


if __name__ == '__main__':
    pass
    # read_weather_data(WEATHER_DATA_FOLDER, "dmi_data_new", 1990, 2021)
    # remove_id_column("../data/dmi_data.csv", DATA_FOLDER + "dmi_data_no_id.csv")
    # average_params_to_1hour(DATA_FOLDER + "dmi_data_new.csv", DATA_FOLDER + "1990-2021_dmi_data.csv")
