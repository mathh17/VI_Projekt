import pandas as pd
import time
from tabulate import tabulate
from matplotlib import pyplot as plt
from project_constants import DATA_FOLDER, RESULT_FOLDER, RESOLUTION_TO_LETTER, ARIMA_DK1_BEST, ARIMA_DK2_BEST, \
    ACCUMULATIVE_PARAMS, PLOT_FOLDER, INTERESTING_PARAMS, TRAIN_SIZE, EL_CONSUMP_FILE, INCLUDE_BOILER_CONSUMPTION
from data_analysis import read_municipality_con
from prediction_funcs import multiple_regression, weather_geo_avg, set_log_folder, log_folder, degree_days, arima, \
    import_el_data, read_all_weather_dfs, pca, get_logger, plot_el_vs_vars, split_timestamps_into_vars, \
    timestamps_to_indicators, lag_df, plot_coefficients_pr_param, get_datetime_column, mean_abs_percentage_error, \
    mean_absolute_error, align_dates, psf, train_test_split, pls_dim_reduction,plot_average_error_per_month
import numpy as np

VERBOSE = True


def compare_weather_vars(residual_plots, time_as_var=False, split_timestamps=None, municipal_average_type=None,
                         plot_coefs=False, plot_error_pr_month=False):
    if time_as_var and split_timestamps:
        raise ValueError("Parameters 'time_as_var' and 'split_timestamps' can't both be true")

    df_stations = pd.read_csv(DATA_FOLDER + "dmi_stations_processed.csv")
    weather_dfs = read_all_weather_dfs()

    def compare_at_resolution(resolution, el_lags, param_lags, hourly_target_res=None):
        for zone in ("DK1", "DK2"):
            if resolution is not None:
                el_avg_res = price_area_to_netcon[zone].resample(RESOLUTION_TO_LETTER[resolution.lower()]).sum()
            else:
                el_avg_res = price_area_to_netcon[zone]
            for df, param in weather_dfs:
                zone_df = df[df.stationId.isin(df_stations[df_stations.priceArea == zone].stationId)]
                zone_geo_avg = weather_geo_avg(zone_df, weight_type=municipal_average_type)
                if resolution is not None:
                    if param in ACCUMULATIVE_PARAMS:
                        zone_geo_avg_res = zone_geo_avg.resample(RESOLUTION_TO_LETTER[resolution.lower()]).sum()
                    else:
                        zone_geo_avg_res = zone_geo_avg.resample(RESOLUTION_TO_LETTER[resolution.lower()]).mean()
                else:
                    zone_geo_avg_res = zone_geo_avg
                if split_timestamps == "standard":
                    time_df = split_timestamps_into_vars(zone_geo_avg_res, resolution)
                    time_df.index.rename("HourUTC", inplace=True)
                    lags = [el_lags, param_lags] + [[0]]
                    res_tup = multiple_regression([el_avg_res, zone_geo_avg_res, time_df], lags, VERBOSE, "HourUTC",
                                                  "{} {} Res. | Lags: El {}, {} {}".format(zone, resolution,
                                                                                           str(el_lags),
                                                                                           param, str(param_lags)),
                                                  residual_plot=residual_plots, time_as_var=time_as_var,
                                                  target_resolution=hourly_target_res,
                                                  return_training_data=plot_coefs,
                                                  plot_error_pr_month=plot_error_pr_month)
                elif split_timestamps == "indicators":
                    indicator_df = timestamps_to_indicators(zone_geo_avg_res, resolution)
                    indicator_df.index.rename("HourUTC", inplace=True)
                    lags = [el_lags, param_lags] + [[0]]
                    res_tup = multiple_regression([el_avg_res, zone_geo_avg_res, indicator_df], lags, VERBOSE,
                                                  "HourUTC",
                                                  "{} {} Res. | Lags: El {}, {} {}".format(zone, resolution,
                                                                                           str(el_lags),
                                                                                           param, str(param_lags)),
                                                  residual_plot=residual_plots, time_as_var=time_as_var,
                                                  target_resolution=hourly_target_res,
                                                  return_training_data=plot_coefs,
                                                  plot_error_pr_month=plot_error_pr_month)
                else:
                    res_tup = multiple_regression([el_avg_res, zone_geo_avg_res], [el_lags, param_lags], VERBOSE,
                                                  "HourUTC",
                                                  "{} {} Res. | Lags: El {}, {} {}".format(zone, resolution,
                                                                                           str(el_lags),
                                                                                           param, str(param_lags)),
                                                  residual_plot=residual_plots, time_as_var=time_as_var,
                                                  target_resolution=hourly_target_res,
                                                  return_training_data=plot_coefs,
                                                  plot_error_pr_month=plot_error_pr_month)
                if plot_coefs:
                    reg_model = res_tup[0]
                    X_train = res_tup[2]
                    plot_coefficients_pr_param(reg_model, X_train, [param], use_normalized_coefs=False, save_plots=True)

    if plot_coefs:
        set_log_folder(RESULT_FOLDER + "monthly_weather_vars_plot_coefs/")
        compare_at_resolution("Monthly", [], [i for i in range(20)])

    set_log_folder(RESULT_FOLDER + "monthly_from_hourly_weather_vars/")
    compare_at_resolution(None, [], [0], hourly_target_res="Monthly")

    set_log_folder(RESULT_FOLDER + "hourly_weather_vars/")
    compare_at_resolution(None, [], [0])

    set_log_folder(RESULT_FOLDER + "daily_weather_vars/")
    compare_at_resolution("Daily", [], [0])

    set_log_folder(RESULT_FOLDER + "weekly_weather_vars/")
    compare_at_resolution("Weekly", [], [0])

    set_log_folder(RESULT_FOLDER + "monthly_weather_vars/")
    compare_at_resolution("Monthly", [], [0])

    set_log_folder(RESULT_FOLDER + "monthly_weather_vars_lag1/")
    compare_at_resolution("Monthly", [], [1])

    set_log_folder(RESULT_FOLDER + "monthly_weather_vars_lag1_2_3_12/")
    compare_at_resolution("Monthly", [], [1, 2, 3, 12])


def compare_degree_days(residual_plots, time_as_var):
    degree_day_dfs = [(degree_days("heating"), "HDD"), (degree_days("cooling"), "CDD")]

    def compare_at_resolution(resolution, el_lags, param_lags):
        for zone in ("DK1", "DK2"):
            if resolution is not None:
                el_avg_res = price_area_to_netcon[zone].resample(RESOLUTION_TO_LETTER[resolution.lower()]).sum()
            else:
                el_avg_res = price_area_to_netcon[zone].resample(RESOLUTION_TO_LETTER["daily"]).sum()
            el_avg_res.index.rename("time", inplace=True)
            for df_dict, param in degree_day_dfs:
                zone_df = df_dict[zone]
                if resolution is not None:
                    zone_df_res = zone_df.resample(RESOLUTION_TO_LETTER[resolution.lower()]).sum()
                else:
                    zone_df_res = zone_df
                zone_df_res.index.rename("time", inplace=True)
                multiple_regression([el_avg_res, zone_df_res], [el_lags, param_lags], VERBOSE, "time",
                                    "{} {} Res. | Lags: El {}, {} {}".format(zone, resolution, str(el_lags),
                                                                             param, str(param_lags)),
                                    residual_plot=residual_plots, time_as_var=time_as_var)

    # set_log_folder(RESULT_FOLDER + "daily_degree_days/")
    # compare_at_resolution(None, [], [0])

    set_log_folder(RESULT_FOLDER + "monthly_degree_days/")
    compare_at_resolution("Monthly", [], [0])


def forecast_netcon_arima(dk1_orders, dk2_orders, normalize_by_workdays=False, plot_error_pr_month=False):
    netcon_dk1_monthly = price_area_to_netcon["DK1"].resample("M").sum()
    netcon_dk2_monthly = price_area_to_netcon["DK2"].resample("M").sum()
    set_log_folder(RESULT_FOLDER + "ARIMA_DK1/")
    arima(netcon_dk1_monthly, dk1_orders[0], dk1_orders[1], VERBOSE, "DK1 NetCon",
          normalize_by_workdays=normalize_by_workdays, residual_plot=True, plot_error_pr_month=plot_error_pr_month)
    set_log_folder(RESULT_FOLDER + "ARIMA_DK2/")
    arima(netcon_dk2_monthly, dk2_orders[0], dk2_orders[1], VERBOSE, "DK2 NetCon",
          normalize_by_workdays=normalize_by_workdays, residual_plot=True, plot_error_pr_month=plot_error_pr_month)


def weather_params_pca(resolution, n_components, split_timestamps=None, arima_errors=None,
                       use_weather_forecast=False, municipal_average_type=None, target_resolution=None, use_pls=False,
                       plot_error_pr_month=False, interpolate="after", param_lag_dict=None, plot_scree=False):
    logger = get_logger(log_folder + "progress_output.txt", "pca_progress_logger")
    df_stations = pd.read_csv(DATA_FOLDER + "dmi_stations_processed.csv")
    weather_dfs = read_all_weather_dfs()
    weather_dfs = list(filter(lambda x: x[1] != "snow_depth_man", weather_dfs))  # snow param contains NaN, so remove
    price_area_to_series_list = {"DK1": [], "DK2": []}
    for price_area in price_area_to_series_list.keys():
        for df, param in weather_dfs:
            zone_df = df[df.stationId.isin(df_stations[df_stations.priceArea == price_area].stationId)]
            zone_geo_avg = weather_geo_avg(zone_df, weight_type=municipal_average_type, interpolate=interpolate)
            if resolution is None:
                zone_geo_avg_res = zone_geo_avg
            else:
                if param in ACCUMULATIVE_PARAMS:
                    zone_geo_avg_res = zone_geo_avg.resample(RESOLUTION_TO_LETTER[resolution.lower()]).sum()
                else:
                    zone_geo_avg_res = zone_geo_avg.resample(RESOLUTION_TO_LETTER[resolution.lower()]).mean()
            if use_weather_forecast:
                psf_mod, X_train = psf(zone_geo_avg_res, resolution, split_based_on=target_resolution,
                                       return_training_data=True, is_accumulative=param in ACCUMULATIVE_PARAMS)
                weather_series = np.concatenate((X_train, psf_mod.preds.flatten()))
                zone_geo_avg_res = pd.Series(weather_series, index=zone_geo_avg_res.index, name=zone_geo_avg_res.name)
            if param_lag_dict is not None:
                zone_geo_avg_res = lag_df(zone_geo_avg_res, param_lag_dict[param])
                zone_geo_avg_res.set_index(get_datetime_column(zone_geo_avg_res), inplace=True)
                zone_geo_avg_res.index.name = param
            price_area_to_series_list[price_area].append(zone_geo_avg_res)

    def pca_regression(num_comps):
        nonlocal el_avg_res
        dim_red_method = "PLS" if use_pls else "PCA"
        if use_pls:
            reduced_matrix, coefs = pls_dim_reduction(all_params_df, el_avg_res, n_components=num_comps,
                                               target_resolution=target_resolution, return_coefs=True)
        else:
            reduced_matrix, new_basis_vecs = pca(all_params_df, num_comps, return_basis_vecs=True)

        reduced_df = pd.DataFrame(reduced_matrix, index=all_params_df.index)
        lags = [[], [0], [0]]
        if split_timestamps == "standard":
            time_df = split_timestamps_into_vars(reduced_df, resolution)
            time_df.index.rename("HourUTC", inplace=True)
            if arima_errors is None:
                model = multiple_regression([el_avg_res, reduced_df, time_df], lags, VERBOSE, "HourUTC",
                                            "{} {} Predictions | {} with {} components | Split Timestamps".format(
                                                price_area, resolution, dim_red_method, reduced_df.shape[1]),
                                            residual_plot=True, time_as_var=False, target_resolution=None,
                                            normalize_input=False, plot_error_pr_month=plot_error_pr_month)
            else:
                exog_df = pd.concat([reduced_df, time_df], axis=1, join="inner")
                el_avg_res, exog_df = align_dates([el_avg_res, exog_df], return_tuple=True)
                model = arima(el_avg_res, arima_errors[0], arima_errors[1], VERBOSE,
                              "{} {} | {} (#PC = {})".format(price_area, resolution, dim_red_method,
                                                             reduced_df.shape[1]),
                              residual_plot=True, exog_vars=exog_df, target_resolution=target_resolution,
                              plot_error_pr_month=plot_error_pr_month)
        elif split_timestamps == "indicators":
            indicator_df = timestamps_to_indicators(reduced_df, resolution)
            indicator_df.index.rename("HourUTC", inplace=True)
            if arima_errors is None:
                model = multiple_regression([el_avg_res, reduced_df, indicator_df], lags, VERBOSE, "HourUTC",
                                            "{} {} Predictions | {} with {} components | Indiciator Timestamps".format(
                                                price_area, resolution, dim_red_method, reduced_df.shape[1]),
                                            residual_plot=True, time_as_var=False, target_resolution=None,
                                            normalize_input=False, plot_error_pr_month=plot_error_pr_month)
            else:
                exog_df = pd.concat([reduced_df, indicator_df], axis=1, join="inner")
                el_avg_res, exog_df = align_dates([el_avg_res, exog_df], return_tuple=True)
                model = arima(el_avg_res, arima_errors[0], arima_errors[1], VERBOSE,
                              "{} {} | {} (#PC = {})".format(price_area, resolution, dim_red_method,
                                                             reduced_df.shape[1]),
                              residual_plot=True, exog_vars=exog_df, target_resolution=target_resolution,
                              plot_error_pr_month=plot_error_pr_month)
        else:
            if arima_errors is None:
                model = multiple_regression([el_avg_res, reduced_df], lags, VERBOSE, "HourUTC",
                                            "{} {} Predictions | {} with {} components | PC Lags: {}".format(
                                                price_area, resolution, dim_red_method, reduced_df.shape[1],
                                                str(lags)),
                                            residual_plot=True, time_as_var=True, normalize_input=False,
                                            plot_error_pr_month=plot_error_pr_month)
            else:
                el_avg_res, reduced_df = align_dates([el_avg_res, reduced_df], return_tuple=True)
                model = arima(el_avg_res, arima_errors[0], arima_errors[1], VERBOSE,
                              "{} {} | {} (#PC = {})".format(price_area, resolution, dim_red_method,
                                                             reduced_df.shape[1]),
                              residual_plot=True, exog_vars=reduced_df, target_resolution=target_resolution,
                              plot_error_pr_month=plot_error_pr_month)
        if use_pls:
            return coefs, model.mae_test
        return new_basis_vecs, model.mae_test

    for price_area in price_area_to_series_list.keys():
        if resolution is None:
            el_avg_res = price_area_to_netcon[price_area]
        else:
            el_avg_res = price_area_to_netcon[price_area].resample(RESOLUTION_TO_LETTER[resolution.lower()]).sum()
        area_series_list = price_area_to_series_list[price_area]
        if param_lag_dict is None:
            all_params_df = pd.concat(area_series_list, axis=1, keys=[series.name for series in area_series_list],
                                      join="inner")
        else:
            all_params_df = pd.concat(area_series_list, axis=1, join="inner")
        el_avg_res.index.rename("HourUTC", inplace=True)
        all_params_df.index.rename("HourUTC", inplace=True)
        if n_components == -1:
            test_errors = []
            components = []
            for i in range(1, all_params_df.shape[1] + 1):
                if VERBOSE:
                    logger.info("{}: Running dimensionality reduction with {} principal components...".
                                format(price_area, i))
                feat_importances, test_error = pca_regression(i)
                components.append(i)
                test_errors.append(test_error)
            if VERBOSE:
                plt.plot(components, test_errors)
                plt.xlabel("Principal Components")
                plt.ylabel("Test MAE")
                plt.title("{}: #Retained PCs vs Mean Absolute Error".format(price_area))
                plt.savefig(log_folder + "{}_PCs_vs_mae{}.png".format(price_area, time.time()), dpi=200)
                plt.show()
            if plot_scree:
                if use_pls:
                    plt.plot(components, feat_importances)
                else:
                    plt.plot(components, feat_importances.iloc[:, 0])
                plt.xlabel("Principal Components")
                plt.ylabel("% Explained Variance")
                plt.title("{}: #Retained PCs vs Relative Explained Variance".format(price_area))
                plt.savefig(log_folder + "{}_PCs_vs_explained_variance{}.png".format(price_area, time.time()), dpi=200)
                plt.show()
        else:
            feat_importances, test_error = pca_regression(n_components)
        if not use_pls:
            logger.info("{} Feature Importances: \n".format(price_area) + tabulate(feat_importances, tablefmt="fancy_grid",
                                                                               headers="keys"))


def notify_user():
    for i in range(10):
        time.sleep(0.5)
        print('\a', end='', flush=True)


def plot_mean_netcon_pr_day():
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    zones = ("DK1", "DK2")
    for zone in zones:
        y = price_area_to_netcon[zone].resample("D").sum()
        week_df = y.groupby(y.index.map(lambda x: x.weekday)).mean()
        week_df.index = days
        plt.bar(week_df.index, week_df.values)
        plt.ylabel("MWh")
        plt.xticks(rotation=-10)
        title = f"{zone} Average NetCon per Weekday"
        plt.title(title)
        plt.savefig(RESULT_FOLDER + title + ".png", dpi=200, bbox_inches="tight")
        plt.show()


def plot_netcon_pr_mun(top_n):
    df_municip = read_municipality_con()
    df_grouped = df_municip.groupby("MunicipalityNo").mean()
    df_grouped.sort_values(by="TotalCon", inplace=True)
    df_municip_codes = pd.read_csv(DATA_FOLDER + "municip_codes.csv")
    df_grouped.index = df_grouped.index.map(lambda x: df_municip_codes[df_municip_codes.Kode == x].Kommunenavn.item())
    df_grouped.tail(top_n).plot.barh(y="TotalCon")
    plt.xticks(rotation=45, ha='right')
    plt.ylabel("Municipality")
    plt.xlabel("MWh")
    plt.title("Mean Monthly Total Energy Consumption per Municipality", loc="right")
    plt.savefig(PLOT_FOLDER + "top_20_municip_totalcon.png", dpi=200)
    plt.show()


def predict_last_years(resolution, target_resolution=None, plot_results=True, plot_error_pr_month=True):
    """
    Naive prediction function that simply predicts last years' consumption for any given timestamp. Similar to what is
    currently used in production. Used to established a baseline for all machine learning models
    :param resolution: The target prediction resolution
    :return:
    """
    res_to_lag = {None: 8760, "Daily": 365, "Weekly": 52, "Monthly": 12}
    for zone in ("DK1", "DK2"):
        if resolution is not None:
            el_avg_res = price_area_to_netcon[zone].resample(RESOLUTION_TO_LETTER[resolution.lower()]).sum()
        else:
            el_avg_res = price_area_to_netcon[zone]

        el_avg_res.index.rename("time", inplace=True)
        X_train, y_train, X_test, y_test = train_test_split(el_avg_res, TRAIN_SIZE, split_based_on=target_resolution)
        lagged_df = lag_df(el_avg_res, [0, res_to_lag[resolution]], "time")
        lagged_df.drop(columns=["time"], inplace=True)

        train = lagged_df.iloc[:len(y_train)]
        test = lagged_df.iloc[-(len(y_test)):]

        train_mape = mean_abs_percentage_error(train.iloc[:, 0].to_numpy().flatten(),
                                               train.iloc[:, 1].to_numpy().flatten())
        train_mae = mean_absolute_error(train.iloc[:, 0].to_numpy().flatten(),
                                        train.iloc[:, 1].to_numpy().flatten())

        test_mape = mean_abs_percentage_error(test.iloc[:, 0].to_numpy().flatten(),
                                              test.iloc[:, 1].to_numpy().flatten())
        test_mae = mean_absolute_error(test.iloc[:, 0].to_numpy().flatten(),
                                       test.iloc[:, 1].to_numpy().flatten())
        print(f"{zone} Train MAPE: {train_mape}, Test MAPE: {test_mape}")
        print(f"{zone} Train MAE: {train_mae}, Test MAE: {test_mae}")
        title = f"{zone}: Predict Last Year's Consumption"
        if plot_results:
            fig, ax = plt.subplots()
            ax.plot_date(y_test.index, test.iloc[:, 1].to_numpy().flatten(), 'r', c="r", zorder=1)
            y_train.plot(ax=ax, c="b", zorder=0, label="Train")
            y_test.plot(ax=ax, c="g", zorder=0, label="Test")
            plt.title(title, y=1.04)
            plt.xlabel("time")
            plt.ylabel("MWh")
            plt.savefig(log_folder + f"{zone} | predict_last_years.png", dpi=200, bbox_inches="tight")
            plt.show()
        if plot_error_pr_month:
            plot_average_error_per_month(test.iloc[:, 0].to_numpy().flatten(), test.iloc[:, 1].to_numpy().flatten()
                                         , y_test.index, title + " Validation")


def predict_mean(resolution, target_resolution=None, use_only_last_n=None, plot_results=True,
                 plot_error_pr_month=True):
    res_to_cycle = {None: 8760, "Daily": 365, "Weekly": 52, "Monthly": 12}
    for zone in ("DK1", "DK2"):
        if resolution is not None:
            el_avg_res = price_area_to_netcon[zone].resample(RESOLUTION_TO_LETTER[resolution.lower()]).sum()
        else:
            el_avg_res = price_area_to_netcon[zone]
        X_train, y_train, X_test, y_test = train_test_split(el_avg_res, TRAIN_SIZE, split_based_on=target_resolution)
        cycle = res_to_cycle[resolution]
        fit = len(X_train) % cycle
        cut_series = X_train[fit:]
        split_idxs = np.arange(cycle, len(cut_series), cycle, dtype=int)
        splits = np.array_split(cut_series, split_idxs)
        if use_only_last_n is not None:
            splits = splits[-use_only_last_n:]
        mean_year = np.mean(splits, axis=0)
        pred = np.concatenate(np.array([mean_year, ] * (len(splits) + int((len(y_test) / cycle) + 1))))
        pred = pred[:len(y_test)]

        y_train = el_avg_res[:len(y_train)]
        y_test = el_avg_res[-len(y_test):]
        pred_test = pred[-len(y_test):]

        test_mape = mean_abs_percentage_error(y_test, pred_test)
        test_mae = mean_absolute_error(y_test, pred_test)
        print(f"{zone} Test MAPE: {test_mape}")
        print(f"{zone} Test MAE: {test_mae}")
        title = f"{zone}: Predict Global Average" if use_only_last_n is None else f"{zone} | Predict Average of Last " \
                                                                                  f"{use_only_last_n} years"
        if plot_results:
            fig, ax = plt.subplots()
            ax.plot_date(y_test.index, pred_test, 'r', c="r", zorder=1)
            y_train.plot(ax=ax, c="b", zorder=0, label="Train")
            y_test.plot(ax=ax, c="g", zorder=0, label="Test")
            plt.title(title, y=1.04)
            plt.xlabel("time")
            plt.ylabel("MWh")
            plt.savefig(log_folder + title + ".png", dpi=200, bbox_inches="tight")
            plt.show()
        if plot_error_pr_month:
            plot_average_error_per_month(y_test, pred_test, y_test.index, title + " Validation")


def predict_all_weather_vars(resolution, residual_plots, time_as_var, split_timestamps=None, municipal_average_type=None,
                             hourly_target_res=None, plot_coefficients=False, global_param_lag=0, param_lag_dict=None):
    df_stations = pd.read_csv(DATA_FOLDER + "dmi_stations_processed.csv")
    weather_dfs = read_all_weather_dfs()
    weather_dfs = list(filter(lambda x: x[1] != "snow_depth_man", weather_dfs))  # snow param contains NaN, so remove
    price_area_to_series_list = {"DK1": [], "DK2": []}
    for price_area in price_area_to_series_list.keys():
        for df, param in weather_dfs:
            zone_df = df[df.stationId.isin(df_stations[df_stations.priceArea == price_area].stationId)]
            zone_geo_avg = weather_geo_avg(zone_df, weight_type=municipal_average_type, verbose=True)
            if resolution is None:
                zone_geo_avg_res = zone_geo_avg
            else:
                if param in ACCUMULATIVE_PARAMS:
                    zone_geo_avg_res = zone_geo_avg.resample(RESOLUTION_TO_LETTER[resolution.lower()]).sum()
                else:
                    zone_geo_avg_res = zone_geo_avg.resample(RESOLUTION_TO_LETTER[resolution.lower()]).mean()
            if param_lag_dict is not None:
                zone_geo_avg_res = lag_df(zone_geo_avg_res, param_lag_dict[param])
                zone_geo_avg_res.set_index(get_datetime_column(zone_geo_avg_res), inplace=True)
                zone_geo_avg_res.index.name = param
            price_area_to_series_list[price_area].append(zone_geo_avg_res)

    for price_area in price_area_to_series_list.keys():
        if resolution is None:
            el_avg_res = price_area_to_netcon[price_area]
        else:
            el_avg_res = price_area_to_netcon[price_area].resample(RESOLUTION_TO_LETTER[resolution.lower()]).sum()
        area_series_list = price_area_to_series_list[price_area]
        if param_lag_dict is None:
            all_params_df = pd.concat(area_series_list, axis=1, keys=[series.name for series in area_series_list],
                                      join="inner")
        else:
            all_params_df = pd.concat(area_series_list, axis=1, join="inner")
        el_avg_res.index.rename("HourUTC", inplace=True)
        all_params_df.index.rename("HourUTC", inplace=True)
        el_lags = []
        param_lags = [i for i in range(global_param_lag + 1)]

        set_log_folder(RESULT_FOLDER)
        if split_timestamps == "standard":
            time_df = split_timestamps_into_vars(all_params_df, resolution)
            time_df.index.rename("HourUTC", inplace=True)
            lags = [el_lags, param_lags] + [[0]]
            reg, X_train = multiple_regression([el_avg_res, all_params_df, time_df], lags, VERBOSE, "HourUTC",
                                               "{} {} Res. | Lags: El {}, Params. {}".format(price_area, resolution,
                                                                                             str(el_lags),
                                                                                             str(param_lags)),
                                               residual_plot=residual_plots, time_as_var=time_as_var,
                                               target_resolution=hourly_target_res,
                                               return_training_data=plot_coefficients)
        elif split_timestamps == "indicators":
            indicator_df = timestamps_to_indicators(all_params_df, resolution)
            indicator_df.index.rename("HourUTC", inplace=True)
            lags = [el_lags, param_lags] + [[0]]
            reg, X_train = multiple_regression([el_avg_res, all_params_df, indicator_df], lags, VERBOSE, "HourUTC",
                                               "{} {} Res. | Lags: El {}, Params. {}".format(price_area, resolution,
                                                                                             str(el_lags),
                                                                                             str(param_lags)),
                                               residual_plot=residual_plots, time_as_var=time_as_var,
                                               target_resolution=hourly_target_res,
                                               return_training_data=plot_coefficients)
        else:
            reg, X_train = multiple_regression([el_avg_res, all_params_df], [el_lags, param_lags], VERBOSE,
                                               "HourUTC",
                                               "{} {} Res. | Lags: El {}, Params. {}".format(price_area, resolution,
                                                                                             str(el_lags),
                                                                                             str(param_lags)),
                                               residual_plot=residual_plots, time_as_var=time_as_var,
                                               target_resolution=hourly_target_res,
                                               return_training_data=plot_coefficients)
        if plot_coefficients:
            plot_coefficients_pr_param(reg, X_train, INTERESTING_PARAMS, save_plots=True)


def run_psf(resolution=None, target_resolution=None, apply_diff=False):
    for price_area in ["DK1", "DK2"]:
        if resolution is None:
            el_avg_res = price_area_to_netcon[price_area]
        else:
            el_avg_res = price_area_to_netcon[price_area].resample(RESOLUTION_TO_LETTER[resolution.lower()]).sum()
        psf_mod = psf(el_avg_res, resolution, target_resolution=target_resolution, verbose=True,
                      plot_title="PSF " + price_area, unit="MWh", is_accumulative=True, plot_error_pr_month=True,
                      apply_diff=apply_diff)


def weather_forecast(resolution=None, target_resolution=None, municipal_average_type=None, interpolate="after",
                     method="psf"):
    df_stations = pd.read_csv(DATA_FOLDER + "dmi_stations_processed.csv")
    weather_dfs = read_all_weather_dfs()
    weather_dfs = list(filter(lambda x: x[1] != "snow_depth_man", weather_dfs))  # snow param contains NaN, so remove
    for price_area in ["DK1", "DK2"]:
        for df, param in weather_dfs:
            zone_df = df[df.stationId.isin(df_stations[df_stations.priceArea == price_area].stationId)]
            zone_geo_avg = weather_geo_avg(zone_df, weight_type=municipal_average_type, verbose=True,
                                           interpolate=interpolate)
            if resolution is None:
                zone_geo_avg_res = zone_geo_avg
            else:
                if param in ACCUMULATIVE_PARAMS:
                    zone_geo_avg_res = zone_geo_avg.resample(RESOLUTION_TO_LETTER[resolution.lower()]).sum()
                else:
                    zone_geo_avg_res = zone_geo_avg.resample(RESOLUTION_TO_LETTER[resolution.lower()]).mean()
            if method == "psf":
                psf_mod = psf(zone_geo_avg_res, resolution, target_resolution=target_resolution, verbose=True,
                              plot_title=f"{param} PSF " + price_area, is_accumulative=param in ACCUMULATIVE_PARAMS,
                              unit=param)
            elif method == "arima":
                arima(zone_geo_avg_res, verbose=True, data_title=f"{price_area} {param}")


if __name__ == '__main__':
    df_electricity = import_el_data(EL_CONSUMP_FILE,
                                include_boiler_con=INCLUDE_BOILER_CONSUMPTION)
    price_area_to_el_df = {"DK1": df_electricity[df_electricity.PriceArea == "DK1"],
                           "DK2": df_electricity[df_electricity.PriceArea == "DK2"]}
    price_area_to_netcon = {}

    for zone, df in price_area_to_el_df.items():
        price_area_to_netcon[zone] = pd.Series(data=df.NetCon.values, index=df.HourUTC)

    original_results = RESULT_FOLDER

    ### Univariate prediction models

    ### Naive models

    # set_log_folder(original_results + "predict_last_years")
    # predict_last_years("Monthly")

    # set_log_folder(original_results + "predict_all_means")
    # for i in range(1, 8):
    #   print(f"Predicting based on average of last {i} years")
    #   predict_mean("Monthly", use_only_last_n=i)

    # set_log_folder(original_results + "predict_mean")
    # predict_mean("Monthly")

    ### ARIMA

    #RESULT_FOLDER = original_results + "arima_manual/"
    #forecast_netcon_arima(ARIMA_DK1_BEST, ARIMA_DK2_BEST, normalize_by_workdays=False,
    #                     plot_error_pr_month=True)

    #RESULT_FOLDER = original_results + "arima_workdays_manual/"
    #forecast_netcon_arima(ARIMA_DK1_BEST, ARIMA_DK2_BEST, normalize_by_workdays=True,
    #                      plot_error_pr_month=True)

    #RESULT_FOLDER = original_results + "arima_auto/"
    #forecast_netcon_arima((None, None), (None, None), normalize_by_workdays=False, plot_error_pr_month=True)


    ### PSF

    #set_log_folder(original_results + "monthly_psf_centroid")
    #run_psf("Monthly", target_resolution=None, apply_diff=False)

    #set_log_folder(original_results + "monthly_from_daily_psf_centroid")
    #run_psf("Daily", target_resolution="Monthly")

    #set_log_folder(original_results + "monthly_from_hourly_psf_centroid")
    #run_psf(None, target_resolution="Monthly", apply_diff=False)

    # set_log_folder(original_results + "psf_monthly_voronoi_weather_centroid_fallback")
    # weather_forecast("Monthly", target_resolution=None, municipal_average_type="voronoi", interpolate="after")


    ### Models using weather parameters

    #RESULT_FOLDER = original_results+"results_no_time/"
    #compare_weather_vars(residual_plots=True, time_as_var=False)

    #RESULT_FOLDER = original_results + "results_time/"
    #compare_weather_vars(residual_plots=True, time_as_var=True, plot_error_pr_month=True)

    # RESULT_FOLDER = original_results + "degree_days_no_time/"
    # compare_degree_days(residual_plots=True, time_as_var=False)

    # RESULT_FOLDER = original_results + "degree_days_time/"
    # compare_degree_days(residual_plots=True, time_as_var=False)

    #set_log_folder(original_results + "monthly_PCA_based/")
    #weather_params_pca("Monthly", n_components=-1, plot_error_pr_month=True)


    #set_log_folder(original_results + "monthly_PCA_PSF_based_autoARIMA_indicator/")
    #weather_params_pca("Monthly", n_components=-1, split_timestamps="indicators", use_weather_forecast=True,
    #                 municipal_average_type=None, target_resolution=None, use_pls=False,
    #                  arima_errors=[[0, 1, 0], [0, 0, 0, 12]], plot_error_pr_month=True)
#
    #set_log_folder(original_results + "monthly_PCA_PSF_based_ARIMA_voronoi_indicator/")
    #weather_params_pca("Monthly", n_components=-1, split_timestamps="indicators", use_weather_forecast=True,
    #                  municipal_average_type="voronoi", interpolate="after", target_resolution=None, use_pls=False,
    #                  arima_errors=[[0, 1, 0], [0, 0, 0, 12]], plot_error_pr_month=True)
#
    #set_log_folder(original_results + "monthly_PCA_PSF_based_ARIMA_correlation_indicator/")
    #weather_params_pca("Monthly", n_components=-1, split_timestamps="indicators",
    #                 use_weather_forecast=True,
    #                 municipal_average_type="correlation", interpolate="after", target_resolution=None, use_pls=False,
    #                  arima_errors=[[0, 1, 0], [0, 0, 0, 12]], plot_error_pr_month=True)
    #
    # set_log_folder(original_results + "ex-post_monthly_PCA_based_autoARIMA_correlation_indicator_timestamps/")
    # weather_params_pca("Monthly", n_components=-1, split_timestamps="indicators",
    #                   use_weather_forecast=False,
    #                   municipal_average_type="correlation", target_resolution=None, use_pls=False, arima_errors=[None, None])

    #set_log_folder(original_results + "monthly_PLS_PSF_based_autoARIMA_indicator/")
    #weather_params_pca("Monthly", n_components=-1, split_timestamps="indicators", use_weather_forecast=True,
    #                 municipal_average_type=None, target_resolution=None, use_pls=True,
    #                   arima_errors=[[0, 1, 0], [0, 0, 0, 12]], plot_error_pr_month=True)
#
    #set_log_folder(original_results + "monthly_PLS_PSF_based_ARIMA_voronoi_indicator/")
    #weather_params_pca("Monthly", n_components=-1, split_timestamps="indicators",
    #                 use_weather_forecast=True,
    #                 municipal_average_type="voronoi", interpolate="after", target_resolution=None, use_pls=True,
    #                  arima_errors=[[0, 1, 0], [0, 0, 0, 12]], plot_error_pr_month=True)
#
    #set_log_folder(original_results + "monthly_PLS_PSF_based_ARIMA_correlation_indicator/")
    #weather_params_pca("Monthly", n_components=-1, split_timestamps="indicators",
    #                   use_weather_forecast=True,
    #                   municipal_average_type="correlation", interpolate="after", target_resolution=None, use_pls=True,
    #                   arima_errors=[[0, 1, 0], [0, 0, 0, 12]], plot_error_pr_month=True)


    # set_log_folder(original_results + "monthly_all_params_lagged_PCA_correlation_indicator_timestamps/")
    # param_lag_dict = {"wind_speed_past1h": [0],
    #                  "temp_mean_past1h": [0],
    #                  "humidity_past1h": [0, 9, 12],
    #                  "precip_past1h": [1, 12],
    #                  "radia_glob_past1h": [0, 1, 2],
    #                  "sun_last1h_glob": [0, 1],
    #                  "temp_grass_mean_past1h": [0, 6, 12],
    #                  "temp_soil_mean_past1h": [0, 1, 6],
    #                  "leav_hum_dur_past1h": [0, 12],
    #                  "pressure": [0, 6],
    #                  "visibility": [0]}
    # weather_params_pca("Monthly", n_components=-1, split_timestamps="indicators",
    #                   municipal_average_type="correlation", use_pls=False, use_weather_forecast=True,
    #                   param_lag_dict=param_lag_dict, arima_errors=[[0, 1, 0], [0, 0, 0, 12]], plot_error_pr_month=True)

