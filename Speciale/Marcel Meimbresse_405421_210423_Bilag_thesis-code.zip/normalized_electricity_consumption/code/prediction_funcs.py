# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import logging
import os
import pmdarima as pm
import geopandas as gpd
import warnings
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from dateutil import relativedelta
from matplotlib.dates import date2num
from scipy.stats import probplot
from sklearn.metrics import mean_absolute_error
from sklearn.metrics.pairwise import haversine_distances
from sklearn.decomposition import PCA
from sklearn.cross_decomposition._pls import _PLS
from workdays import networkdays
from math import floor
from geovoronoi import voronoi_regions_from_coords
from geovoronoi.plotting import subplot_for_map, plot_voronoi_polys_with_points_in_area
from collections import Counter
from linear_regression import LinearRegression
from PSF import Psf
from project_constants import RESOLUTION_TO_LETTER, RESULT_FOLDER, DATA_FOLDER, \
    DMI_FILE, ACCUMULATIVE_PARAMS, ZONE_TO_REGIONS, PLOT_FOLDER, INTERESTING_PARAMS, TRAIN_SIZE, EL_CONSUMP_FILE
from data_analysis import auto_corr_plot, read_weather_data, import_el_data, import_dmi_data, import_station_dataframe,\
    read_municipality_con, read_municipality_geo_data

log_folder = RESULT_FOLDER


def set_log_folder(folder_name):
    """
    Sets the global 'log_folder' to 'folder_name' and creates the folder path if it does not exist yet
    :param folder_name:
    :return:
    """
    global log_folder
    if folder_name[-1] != "/":
        folder_name = folder_name + "/"
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)
    log_folder = folder_name


def psf(in_df, resolution, is_accumulative, target_resolution=None, verbose=False, time_column=None, plot_title="PSF",
        return_training_data=False, unit="value", split_based_on=None, plot_error_pr_month=False, apply_diff=False):
    res_to_cycle = {None: 24, "Hourly": 8760, "Daily": 365, "Monthly": 12}
    X_train, y_train, X_test, y_test = train_test_split(in_df, TRAIN_SIZE, time_column,
                                                        split_based_on=target_resolution or split_based_on)
    cycle = res_to_cycle[resolution]
    psf_mod = Psf(X_train, cycle, apply_diff=apply_diff, diff_periods=8760 if resolution is None else 1)
    pred = psf_mod.predict(n_ahead=len(y_test), k_values=tuple(range(2, 30)), w_values=tuple(range(1, 21)))
    y_pred_test = pd.Series(pred, index=y_test.index)

    if target_resolution is not None:
        if is_accumulative:
            y_train = y_train.resample(RESOLUTION_TO_LETTER[target_resolution.lower()]).sum()
            y_test = y_test.resample(RESOLUTION_TO_LETTER[target_resolution.lower()]).sum()
            y_pred_test = y_pred_test.resample(RESOLUTION_TO_LETTER[target_resolution.lower()]).sum()
        else:
            y_train = y_train.resample(RESOLUTION_TO_LETTER[target_resolution.lower()]).mean()
            y_test = y_test.resample(RESOLUTION_TO_LETTER[target_resolution.lower()]).mean()
            y_pred_test = y_pred_test.resample(RESOLUTION_TO_LETTER[target_resolution.lower()]).mean()

    parent_log_folder = log_folder
    set_log_folder(log_folder + plot_title + "/")
    mape_test = mean_abs_percentage_error(np.array(y_test).flatten(), np.array(y_pred_test).flatten())
    mae_test = mean_absolute_error(np.array(y_test).flatten(), np.array(y_pred_test).flatten())
    psf_mod.mape_test = mape_test
    psf_mod.mae_test = mae_test
    if verbose:
        logger = get_logger(log_folder + plot_title, plot_title)
        logger.info(plot_title + ":")
        logger.info("MAPE: Test: {}".format(mape_test))
        logger.info("MAE: Test: {}".format(mae_test))
        remove_logger(logger)
        fig, ax = plt.subplots()
        ax.plot_date(date2num(y_test.index), y_pred_test, 'r', c="r", zorder=1)
        y_train.plot(ax=ax, c="b", zorder=0, label="Train")
        y_test.plot(ax=ax, c="g", zorder=0, label="Test")
        plt.title(plot_title, y=1.04)  # Raise title to clear y-axis coefficient (e.g., "1e6")
        plt.xlabel("time")
        plt.ylabel(unit)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            plt.legend(["Prediction", "Train", "Test"])
        plt.savefig(log_folder + plot_title + ".png", dpi=200, bbox_inches="tight")
        plt.show()
    if plot_error_pr_month:
        plot_average_error_per_month(y_test, y_pred_test, y_test.index, plot_title + " Validation")
    set_log_folder(parent_log_folder)
    psf_mod.y_pred_test = y_pred_test
    if return_training_data:
        return psf_mod, X_train
    return psf_mod


def get_datetime_column(in_df):
    """
    # Returns the first of [index, column_1, column_2, ..., column_n] that has type datetime
    :param in_df:
        DataFrame
    :return:
        The string of the the datetime column or "index", if 'in_df' has a datetime index
    """
    time_axis = None
    if in_df.index.dtype == np.dtype('datetime64[ns]'):
        time_axis = "index"
    else:
        for name, type_ in in_df.dtypes.reset_index().values:
            if type_ == np.dtype('datetime64[ns]'):
                time_axis = name
                break
    if time_axis is None:
        raise ValueError("Could not find datetime index or column in DataFrame")
    return time_axis


def lag_df(in_df, time_lags, time_column=None, drop_na=True):
    """
    Adds lagged columns to a Series (thus converting it to a DataFrame) or DataFrame
    Side effect: Will convert all non-time column names to string and (if 'in_df' has a datetime index)
                 reset the index of 'in_df'
    :param in_df:
        DataFrame or Series. Must have a DateTime index.
    :param time_lags:
        List of individual time lags to apply to 'in_df'.
    :param time_column: optional, default None
        The datetime column to use for lagging. If 'None', the first of [index, column_1, column_2, ..., column_n] that
        has type datetime will be used.
    :param drop_na: optional, default True
        If 'True', the first date of the final lagged DataFrame will be equal to first date of column with the largest
        lag. If 'False', the first date is unchanged and so all lagged columns will contain NaN values at the start
    :return:
        A DataFrame with each column i being 'in_df' lagged by 'time_lags'[i] time steps.
    """
    series_name = in_df.name if type(in_df) == pd.Series else None
    time_axis = get_datetime_column(in_df)
    if time_axis != "index":
        if time_column is not None:
            in_df = in_df.set_index(time_column)
        else:
            in_df = in_df.set_index(time_axis)
            time_column = time_axis
    df_list = []
    for i, lag in enumerate(time_lags):
        if drop_na:
            df_list.append(in_df.shift(lag).dropna().reset_index())
        else:
            df_list.append(in_df.shift(lag).reset_index())
        if type(in_df) == pd.Series:
            if in_df.name is None:
                df_list[i].rename(columns={0: "lag_{}".format(lag)}, inplace=True)
            else:
                df_list[i].rename(columns={series_name: series_name + ":lag_{}".format(lag)},
                                  inplace=True)
        elif type(in_df) == pd.DataFrame:
            columns = in_df.columns.to_list()
            lag_columns = list(filter(lambda x: x != time_column, columns))
            new_column_dict = {column: str(column) + ":lag_{}".format(lag) for column in lag_columns}
            df_list[i].rename(columns=new_column_dict, inplace=True)
    min_date = df_list[-1].index[0]
    for i in range(len(df_list)):
        df_list[i] = df_list[i][df_list[i].index >= min_date]
    final_df = df_list[0]
    for df in df_list[1:]:
        final_df = final_df.merge(df, on=time_column)
    return final_df


def gps_distance(a, b):
    return haversine_distances([np.radians([a.Latitude, a.Longitude]), np.radians([b.Latitude, b.Longitude])])[0][1]


def spatial_interpolation(in_df, verbose=False, use_temporal_first=False):
    """
    :param in_df:
    :param verbose:
    :param use_temporal_first:
        Precede the geospatial interpolation by first applying temporal interpolation to each station time series,
        filling only gaps of size 1 that are surrounded by valid measurements.
    :return:
    """

    def _spatial_interpolation(grouped_df):
        min_date = in_df.index[0]
        max_date = in_df.index[-1]
        total_hours = int((max_date - min_date).total_seconds() // 3600)
        correct_index = pd.to_datetime(np.linspace(min_date.value, max_date.value, total_hours + 1))
        total_missing_timestamps = 0
        station_id_to_dict = {}
        for station_id, station_df in grouped_df:
            station_id_to_dict[station_id] = station_df.value.to_dict()
        df_list = []
        for station_id, station_df in grouped_df:
            if use_temporal_first:
                station_df = interpolate_missing_timestamps(station_df)
            station_df_dict = station_df.to_dict("index")
            timestamp_dict = Counter(station_df.index)
            missing_date_count = 0
            interpolated_count = 0
            interpolation_failure = False

            for correct_date in correct_index:
                if timestamp_dict.get(correct_date) is None:
                    missing_date = correct_date
                    missing_date_count += 1
                    station_neighbors = station_to_neighbors[station_id]
                    neighbor_vals = []
                    neighbor_count = 0
                    for neighbor in station_neighbors:
                        neighbor_df_dict = station_id_to_dict[neighbor]
                        neighbor_val = neighbor_df_dict.get(missing_date)
                        if neighbor_val is None:
                            continue
                        neighbor_count += 1
                        neighbor_vals.append(neighbor_val)
                        if neighbor_count == 2:
                            break
                    if neighbor_count == 0:
                        warnings.warn("Spatial interpolation Failed: All stations missing date {} for parameter {}"
                                      .format(missing_date, param))
                        interpolation_failure = True
                        continue
                    station_df_dict[missing_date] = {"parameterId": param, "stationId": station_id,
                                                     "value": np.mean(neighbor_vals)}
                    interpolated_count += 1
            if verbose:
                print(station_id, "Missing dates:", missing_date_count, ", interpolated:", interpolated_count)
            total_missing_timestamps += missing_date_count
            new_station_df = pd.DataFrame.from_dict(station_df_dict, "index")
            new_station_df.index.name = station_df.index.name
            new_station_df.sort_index(kind="mergesort", inplace=True)
            if interpolation_failure:
                interpolate_missing_timestamps(new_station_df, verbose=verbose)
            df_list.append(new_station_df)
        return pd.concat(df_list)

    date_column = get_datetime_column(in_df)
    if date_column != "index":
        in_df.set_index(date_column, inplace=True)
    param = in_df.parameterId.iloc[0]
    df_stations = import_station_dataframe(DATA_FOLDER + "dmi_stations.json", in_df)
    station_to_neighbors = {}
    for row1 in df_stations.itertuples():
        station_distances = []
        for row2 in df_stations.itertuples():
            if row1.stationId != row2.stationId:
                distance = gps_distance(row1, row2)
                station_distances.append((row2.stationId, distance))
        sorted_distances = sorted(station_distances, key=lambda x: x[1])
        station_to_neighbors[row1.stationId] = list(map(lambda x: x[0], sorted_distances))
    in_df_grouped = in_df.groupby("stationId")
    return _spatial_interpolation(in_df_grouped)


def interpolate_missing_timestamps(in_df, method="temporal", verbose=False):
    """
    Interpolates missing data points if they're surrounded by valid data.
    :param method:
        The method of interpolation. Must be either 'temporal' or 'spatial'. If 'spatial', the k-nearest stations are
        used to linearly interpolate missing dates, with starting k=2. To lessen the effect of erronous values, ideally
        two stations are used for interpolation. If one of the 2 nearest stations is also missing the current date, k
        is increased by one, until 2 stations that have observations for the missing date have been found. If only one
        station can be found, it's value is used. If all stations are missing the current date, a warning is issued and
        a recursive call using 'temporal' interpolation will be issued once the spatial interpolation on the current
        station DataFrame has finished.
    :param in_df:
        DataFrame if "method" == 'spatial' else Series. Must have a datetime index, with the time difference between the
        first two rows representing the desired temporal resolution. Hence, the first two rows must contain valid
        observations. Must only contain observations of a single weather parameter. If "method" == 'spatial", columns
        must be 'parameterId', 'stationId', 'value' (in that order)
    :param verbose: optional, default False
        If 'True', prints out all missing time steps (dates).
    :return:
        Series if "method" == 'temporal' or DataFrame if "method" == 'spatial' or "method" == 'both'
    """
    if method not in ["temporal", "spatial", "spatiotemporal"]:
        raise ValueError("parameter 'method' must be one of ['temporal', 'spatial', 'spatiotemporal']")
    if verbose:
        if isinstance(in_df, pd.core.frame.DataFrame):
            print("{}ly interpolating data for {}...".format(method.capitalize(), in_df.parameterId.iloc[0]))
        else:
            print("{}ly interpolating data for {}...".format(method.capitalize(), in_df.name))

    in_df = in_df.copy(deep=True)  # avoid setting with copy
    if not in_df.index.is_monotonic:
        in_df.sort_index(inplace=True)
    if method.lower() == "temporal":
        hour_delta = in_df.index[1] - in_df.index[0]
        index_series = in_df.index.to_series()
        shifted_dates = pd.DataFrame(np.column_stack([index_series.iloc[1:], index_series.iloc[:-1]]))
        deltas = shifted_dates.iloc[:, 0] - shifted_dates.iloc[:, 1]
        orig_missing_dates = index_series[:-1][(deltas != hour_delta).values] + hour_delta
        time_stamp_dict = Counter(in_df.index)
        missing_dates = orig_missing_dates[((orig_missing_dates - hour_delta).map(time_stamp_dict) &
                                           (orig_missing_dates + hour_delta).map(time_stamp_dict)).astype(bool)]
        if isinstance(in_df, pd.core.frame.DataFrame):
            in_df_dict = in_df.to_dict("index")
            preceding_values = (missing_dates - hour_delta).map(lambda x: in_df_dict[x]["value"])
            succeeding_values = (missing_dates + hour_delta).map(lambda x: in_df_dict[x]["value"])
            interpol_values = np.mean((preceding_values, succeeding_values), axis=0)
            param = in_df.parameterId.iloc[0]
            station_id = in_df.stationId.iloc[0]
            for missing_date, value in zip(missing_dates, interpol_values):
                in_df_dict[missing_date] = {"parameterId": param, "stationId": station_id,
                                            "value": value}
            interpolated = pd.DataFrame.from_dict(in_df_dict, "index")
        else:  # pd.Series
            in_df_dict = in_df.to_dict()
            preceding_values = (missing_dates - hour_delta).map(lambda x: in_df_dict[x])
            succeeding_values = (missing_dates + hour_delta).map(lambda x: in_df_dict[x])
            interpol_values = np.mean((preceding_values, succeeding_values), axis=0)
            for missing_date, value in zip(missing_dates, interpol_values):
                in_df_dict[missing_date] = value
            interpolated = pd.Series(in_df_dict)
            interpolated.name = in_df.name
        if verbose:
            print("Found {} missing dates, re-estimated {}".format(orig_missing_dates.size, missing_dates.size))
        interpolated.index.name = in_df.index.name
        interpolated.sort_index(kind="mergesort", inplace=True)
        return interpolated
    elif method.lower() == "spatial":
        return spatial_interpolation(in_df, verbose=verbose)
    else:  # method == "spatiotemporal":
        return spatial_interpolation(in_df, verbose=verbose, use_temporal_first=True)


def train_test_split(in_df, train_size, time_column=None, split_based_on=None):
    """
    Splits a DataFrame into training and testing data along a time axis
    :param split_based_on:
        Split based on a different time resolution than the given in_df. Can be one of ['Daily', 'Monthly'].
        For example, 'Daily' would split the data at the boundary between two days, such that each distinct day is put
        into either the training og testing partition and no day can be split a training and a testing part.
    :param in_df:
        DataFrame. Is assumed to be sorted by time. The variable to be predicted must be located in a column with
        name 'lag_0'. Must have at least one datetime column.
    :param train_size:
        Size of the training partition. 'train_size' == 0.5 => 50% of all data is used as training data.
    :param time_column: optional, default None
        The datetime column to use for splitting 'in_df'. If 'None', the first of [index, column_1, column_2, ...,
        column_n] that has type datetime will be used.
    :return:
        X, y, X', y', where X and X' are the input/independent variables of the training and testing partition,
        respectively and y, y' are the observed values (to be predicted) of the training and testing partition,
        respectively. All returned DataFrames have a datetime index based on 'time_column'.
    """

    def timestamp_pos(df, timestamp, time_column=None):
        if time_column is not None:
            date_series = pd.Index(df[time_column])
        else:
            date_series = df.index
        try:
            _split_idx = date_series.get_loc(timestamp)
        except KeyError:
            closest_timestamp = date_series[date_series >= split_datetime].take([0]).item()
            _split_idx = date_series.get_loc(closest_timestamp)
        return _split_idx

    if split_based_on is not None:
        if time_column is None:
            resampled_idx = in_df.resample(RESOLUTION_TO_LETTER[split_based_on.lower()]).first().index
            split_datetime = resampled_idx[int(train_size * len(resampled_idx))]
            if split_based_on.lower() == "monthly":
                split_datetime = split_datetime + relativedelta(days=+1)
            split_idx = timestamp_pos(in_df, split_datetime)
        else:
            resampled_idx = in_df.resample(RESOLUTION_TO_LETTER[split_based_on.lower()], on=time_column).first().index
            split_datetime = resampled_idx[int(train_size * len(resampled_idx))]
            if split_based_on.lower() == "monthly":
                split_datetime = split_datetime + relativedelta(days=+1)
            split_idx = timestamp_pos(in_df, split_datetime, time_column=time_column)
        split = np.array_split(in_df, [split_idx])
    else:
        split = np.array_split(in_df, [int(train_size * len(in_df))])
    if time_column is None:
        if type(in_df) == pd.Series:
            y_train = split[0]
            y_test = split[1]
        else:
            y_train = pd.DataFrame(data=split[0].lag_0.values, index=split[0].index.values)
            y_test = pd.DataFrame(data=split[1].lag_0.values, index=split[1].index.values)
    else:
        if type(in_df) == pd.Series:
            y_train = split[0]
            y_test = split[1]
        else:
            y_train = pd.DataFrame(data=split[0].lag_0.values, index=split[0][time_column].values)
            y_test = pd.DataFrame(data=split[1].lag_0.values, index=split[1][time_column].values)
    split[0].drop(columns=["lag_0"], inplace=True)
    split[1].drop(columns=["lag_0"], inplace=True)
    return split[0], y_train, split[1], y_test


def mean_abs_percentage_error(y_true, y_pred):
    """
    Calculates the Mean Absolute Percentage Error (MAPE)
    :param y_true:
        The array of observed values.
    :param y_pred:
        The array of predicted values.
    :return:
        MAPE
    """
    y_true = np.where(y_true != 0, y_true, 1e-7)  # avoid division by zero
    return np.mean(np.abs(y_true - y_pred) / np.abs(y_true))


def plot_residuals(X, y_true, y_pred, plot_title_prefix):
    """
    Plots residuals vs each independent variable, as well as residuals vs predicted values, the sample autocorrelation
    function and sample partial autocorrelation function of the residuals.
    :param X:
        DataFrame or two-dimensional Numpy array, where each column represents an independent variable.
    :param y_true:
        The array of observed values.
    :param y_pred:
        The array of predicted values.
    :param plot_title_prefix:
        A string that will precede each plot title.
    :return:
    """
    res = np.array(y_true).flatten() - np.array(y_pred).flatten()
    auto_corr_fig = auto_corr_plot(res, "Residual", partial=False)
    auto_corr_fig.savefig("{}{} residual_autocorr.png".format(log_folder, plot_title_prefix), dpi=200)
    part_auto_corr_fig = auto_corr_plot(res, "Residual", partial=True)
    part_auto_corr_fig.savefig("{}{} partial_residual_autocorr.png".format(log_folder, plot_title_prefix), dpi=200)
    if X is not None:
        if isinstance(X, pd.core.frame.DataFrame):
            cols = X.columns
            for column in cols:
                plt.scatter(X[column], res)
                plt.title("{} vs Residuals".format(column))
                plt.xlabel(column)
                plt.ylabel("Residual")
                plt.savefig("{}{} {} res.png".format(log_folder, plot_title_prefix, column), dpi=200)
                plt.show()
        else:
            for i, column in enumerate(X.T):
                plt.scatter(column, res)
                col_name = "x" + str(i)
                plt.title("{} vs Residuals".format(col_name))
                plt.xlabel(col_name)
                plt.ylabel("Residual")
                plt.savefig("{}{} {} res.png".format(log_folder, plot_title_prefix, col_name), dpi=200)
                plt.show()

    fig, ax = plt.subplots()
    probplot(res, plot=ax)
    plt.title("Residual Normal Probability Plot")
    plt.savefig("{}{} residuals_prob.png".format(log_folder, plot_title_prefix), dpi=200)
    plt.show()

    plt.scatter(np.array(y_pred).flatten(), res)
    plt.title("Predicted vs Residuals")
    plt.xlabel("Predicted")
    plt.ylabel("Residual")
    plt.savefig("{}{} predicted_vs_residuals.png".format(log_folder, plot_title_prefix), dpi=200)
    plt.show()


def calcnlog_metrics(reg, X_train, y_train, X_test, y_test, y_pred_train, y_pred_test, plot_title, verbose=False):
    """
    Logs Regression model coefficients, normalized coefficient, coefficient t/p-values and calculates and subsequently
    logs R-squared, mean absolute percentage error and mean absolute error on in-sample and out-of-sample data.
    :param reg:
        An Sklearn regression model
    :param X_train:
        The input/independent variables of the training (in-sample) data
    :param y_train:
        The observed values of the training data
    :param X_test:
        The input/independent variables of the testing (out-of-sample) data
    :param y_test:
        The observed values of the testing data
    :param y_pred_train:
        The predicted values of the training data
    :param y_pred_test:
        The predicted values of the testing data
    :param plot_title:
        The log file name
    :return:
    """
    mape_train = mean_abs_percentage_error(np.array(y_train).flatten(), np.array(y_pred_train).flatten())
    mape_test = mean_abs_percentage_error(np.array(y_test).flatten(), np.array(y_pred_test).flatten())
    mae_train = mean_absolute_error(np.array(y_train).flatten(), np.array(y_pred_train).flatten())
    mae_test = mean_absolute_error(np.array(y_test).flatten(), np.array(y_pred_test).flatten())
    reg.mape_train = mape_train
    reg.mape_test = mape_test
    reg.mae_train = mae_train
    reg.mae_test = mae_test
    if verbose:
        logger = get_logger(log_folder + plot_title, plot_title)
        logger.info(plot_title + ":")
        logger.info("Coefficients: {}".format(str(list(zip(X_train.columns, reg.coef_[0])))))
        if reg.normalize:
            logger.info("Normalized Coefficients: {}".format(str(list(zip(X_train.columns, reg.coef_normalized_[0])))))
        logger.info("Coefficient t-values: {}".format(str(list(zip(X_train.columns, reg.t[0])))))
        logger.info("Coefficient p-values: {}".format(str(list(zip(X_train.columns, reg.p[0])))))
        logger.info("R^2 score: Train: {}    Test: {}".format(reg.score(X_train, y_train), reg.score(X_test, y_test)))
        logger.info("MAPE: Train: {}    Test: {}".format(mape_train, mape_test))
        logger.info("MAE: Train:{}    Test: {}".format(mae_train, mae_test))
        remove_logger(logger)


def regression(in_df, time_column, verbose, plot_title, residual_plot=False, time_as_var=False, target_resolution=None,
               return_training_data=False, normalize_input=True, plot_error_pr_month=False):
    """
    Applies a regression model to 'in_df' and generates in and out-of-sample predictions
    :param in_df:
        DataFrame with at least one datetime column and one column named 'lag_0' to be used as the dependent variable.
    :param time_column:
        The datetime column to be used for splitting 'in_df' into training/testing partitions and plotting predictions
    :param verbose:
        If True, generate a log file of regression model coefficients and metrics and plot predictions vs observed
        values.
    :param plot_title:
        The string to be used as the log folder holding the log file and saved plots, as well as being the title of the
        prediction vs observed value plot.
    :param residual_plot: optional, default False
        If True, plot residuals vs each independent variable, residuals vs predictions and residual autocorrelation.
    :param time_as_var: optional, default False
        If True, include time as an independent variable in the regression model.
    :return:
        The fitted regression model and the generated out-of-sample predictions
    """
    X_train, y_train, X_test, y_test = train_test_split(in_df, TRAIN_SIZE, time_column,
                                                        split_based_on=target_resolution)
    if not time_as_var:
        X_train.drop(columns=time_column, inplace=True)
        X_test.drop(columns=time_column, inplace=True)
    else:
        X_train[time_column] = date2num(X_train[time_column])
        X_test[time_column] = date2num(X_test[time_column])
    reg = LinearRegression(normalize=normalize_input).fit(X_train, y_train)
    y_pred_train = (X_train.to_numpy() * reg.coef_).sum(axis=1) + reg.intercept_
    y_pred_test = (X_test.to_numpy() * reg.coef_).sum(axis=1) + reg.intercept_
    if target_resolution is not None:
        train_index = y_train.index
        test_index = y_test.index
        X_train.index = train_index
        X_test.index = test_index
        X_train = X_train.resample(RESOLUTION_TO_LETTER[target_resolution.lower()]).sum()
        X_test = X_test.resample(RESOLUTION_TO_LETTER[target_resolution.lower()]).sum()
        y_train = y_train.resample(RESOLUTION_TO_LETTER[target_resolution.lower()]).sum()
        y_test = y_test.resample(RESOLUTION_TO_LETTER[target_resolution.lower()]).sum()
        y_pred_train = pd.Series(y_pred_train, index=train_index)
        y_pred_test = pd.Series(y_pred_test, index=test_index)
        y_pred_train = y_pred_train.resample(RESOLUTION_TO_LETTER[target_resolution.lower()]).sum()
        y_pred_test = y_pred_test.resample(RESOLUTION_TO_LETTER[target_resolution.lower()]).sum()
    if verbose:
        parent_log_folder = log_folder
        set_log_folder(log_folder + plot_title + "/")
        calcnlog_metrics(reg, X_train, y_train, X_test, y_test, y_pred_train, y_pred_test, plot_title, verbose)
        fig, ax = plt.subplots()
        ax.plot_date(date2num(y_train.index), y_pred_train, 'r', c="r", zorder=1)
        ax.plot_date(date2num(y_test.index), y_pred_test, 'r', c="r", zorder=1)
        y_train.plot(ax=ax, c="b", zorder=0, label="Train")
        y_test.plot(ax=ax, c="g", zorder=0, label="Test")
        plt.title(plot_title, y=1.04)  # Raise title to clear y-axis coefficient (e.g., "1e6")
        plt.xlabel("time")
        plt.ylabel("MWh")
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            plt.legend(["_", "Prediction", "Train", "Test"])
        plt.savefig(log_folder + plot_title + ".png", dpi=200, bbox_inches="tight")
        plt.show()
        if residual_plot:
            plot_residuals(X_train, y_train, y_pred_train, plot_title)
        if plot_error_pr_month:
            plot_average_error_per_month(y_test, y_pred_test, y_test.index, plot_title + " Validation")
        set_log_folder(parent_log_folder)
    else:
        calcnlog_metrics(reg, X_train, y_train, X_test, y_test, y_pred_train, y_pred_test, plot_title, verbose)
    reg.y_pred_test = y_pred_test
    if return_training_data:
        return reg, in_df
    return reg


def univariate_regression(in_df, time_lags, verbose, time_column, plot_title=None, residual_plot=False,
                          time_as_var=False, return_training_data=False, normalize_input=True):
    """
    Applies a regression model to a time series consisting of a single variable. Uses the value of the variable at
    previous time steps to predict the current value.
    :param in_df:
        The DataFrame of the variable time series. Must have one datetime column
    :param time_lags:
        The time lags of the variable to later use as "independent" variables.
    :param verbose:
        See 'regression'
    :param time_column:
        See 'regression'
    :param plot_title:
        See 'regression'
    :param residual_plot:
        See 'regression'
    :param time_as_var:
        See 'regression'
    :return:
        See 'regression'
    """
    lagged_df = lag_df(in_df, [0] + time_lags, time_column)
    return regression(lagged_df, time_column, verbose, plot_title, residual_plot, time_as_var, return_training_data,
                      normalize_input)


def align_dates(df_list, return_tuple=False):
    """
    Aligns two or more Dataframes based on the intersection of their (datetime) indices.
    :param df_list:
        List of DataFrames
    :return:
    """
    time_axes = []
    for df in df_list:
        if df.index.dtype == np.dtype('datetime64[ns]'):
            time_axes.append("index")
        else:
            for name, type_ in df.dtypes.reset_index().values:
                if type_ == np.dtype('datetime64[ns]'):
                    time_axes.append(name)
                    break
    if len(time_axes) != len(df_list):
        raise ValueError("Could not find datetime index or column in a DataFrame")

    date_index_list = [df_list[i].index if time_axes[i] == "index" else pd.Index(df_list[i][time_axes[i]])
                       for i in range(len(df_list))]
    new_index = date_index_list[0]
    for idx in date_index_list[1:]:
        new_index = new_index.intersection(idx)
    for i in range(len(df_list)):
        if time_axes[i] == "index":
            df_list[i] = df_list[i].loc[new_index]
        else:
            idx_dict = Counter(new_index.to_list())
            df_list[i] = df_list[i][df_list[i][time_axes[i]].map(idx_dict).astype(bool)]
    if return_tuple:
        return tuple(df_list)
    return df_list


def plot_coefficients_pr_param(reg_model, X_train, params, use_normalized_coefs=True, save_plots=False):
    """
    Creates a bar plot of the regression coefficients of each parameter. A separate plot is created for each parameter.
    :param reg_model:
        Regression model fitted to X_train
    :param X_train:
        The training data used in 'reg_model'
    :param params:
        The parameters contained in the columns of 'X_train'
    :param use_normalized_coefs:
        Whether to use normalized or de-normalized coefficients.
    :param save_plots:
        Whether to save the figures to the RESULT_FOLDER
    :return:
    """
    if use_normalized_coefs:
        coefs = list(zip(X_train.columns, reg_model.coef_normalized_[0]))
    else:
        coefs = list(zip(X_train.columns, reg_model.coef_[0]))
    normalized_string = " normalized" if use_normalized_coefs is True else ""
    for param in params:
        x = []
        y = []
        for tup in coefs:
            if param in tup[0]:
                x.append(int(tup[0].split(":")[1].split("_")[1]))
                y.append(tup[1])
        plt.bar(x=x, height=y)
        plt.title("{}{} regression coefficients per time lag".format(param, normalized_string))
        plt.xlabel("Time lag")
        plt.xticks(np.arange(0, len(x)), rotation=-35)
        plt.grid(True)
        plt.ylabel("Coeff.")
        if save_plots:
            plt.savefig(RESULT_FOLDER + "{}_regression_coefficients.png".format(param), dpi=200)
        plt.show()


def multiple_regression(in_dfs, time_lags_pr_param, verbose, time_column=None, plot_title=None, residual_plot=False,
                        time_as_var=False, target_resolution=None, return_training_data=False,
                        normalize_input=True, plot_error_pr_month=False):
    """
    Applies multiple regression to 'in_df'
    :param in_dfs:
        List of DataFrames. First DataFrame must only contain the dependent variable and a datetime column.
        All dfs must have a datetime index or contain a datetime column. All DataFrames must have the same time
        resolution.
    :param time_lags_pr_param:
         List of lists. The timelags to apply to each DataFrame in 'in_dfs', respectively. Must have same length as
         'in_dfs'
    :param verbose:
        See 'regression'
    :param time_column:
        See 'regression'
    :param plot_title:
        See 'regression'
    :param residual_plot:
        See 'regression'
    :param time_as_var:
        See 'regression'
    :return:
        See 'regression'
    """
    main_lagged_df = lag_df(in_dfs[0], [0] + time_lags_pr_param[0], time_column)
    param_lagged_dfs = [lag_df(in_dfs[i], time_lags_pr_param[i], time_column) for i in range(1, len(in_dfs))]
    df_list = [main_lagged_df] + param_lagged_dfs
    final_df = df_list[0]
    for df in df_list[1:]:
        final_df = final_df.merge(df, on=time_column)
    return regression(final_df, time_column, verbose, plot_title, residual_plot, time_as_var, target_resolution,
                      return_training_data, normalize_input, plot_error_pr_month=plot_error_pr_month)


def timestamps_to_indicators(in_df, temp_resolution):
    time_col = get_datetime_column(in_df)
    months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
              "November"]
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    hours = [hour for hour in range(0, 23)]
    zero_column = pd.Series(np.zeros(len(in_df)))
    if temp_resolution.lower() == "monthly" or temp_resolution.lower() == "weekly":
        column_names = months
        indicator_df = pd.concat([zero_column for _ in range(len(months))], axis=1)
    elif temp_resolution.lower() == "daily":
        column_names = months + days
        indicator_df = pd.concat([zero_column for _ in range(len(months) + len(days))], axis=1)
    else:  # Hourly
        column_names = months + days + hours
        indicator_df = pd.concat([zero_column for _ in range(len(months) + len(days) + len(hours))], axis=1)
    indicator_df.columns = column_names
    indicator_df.index = in_df.index if time_col == "index" else in_df[time_col]

    def fill_indicator_df(timestamp):
        nonlocal indicator_df
        month = timestamp.month_name()
        if month != "December":
            indicator_df.at[timestamp, month] = 1
        if temp_resolution.lower() == "daily" or temp_resolution.lower() == "hourly" or temp_resolution is None:
            day = timestamp.day_name()
            if day != "Sunday":
                indicator_df.at[timestamp, day] = 1
        if temp_resolution.lower() == "hourly" or temp_resolution is None:
            hour = timestamp.hour
            if hour != 23:
                indicator_df.at[timestamp, hour] = 1

    if time_col == "index":
        in_df.index.to_series().apply(fill_indicator_df)
    else:
        in_df[time_col].apply(fill_indicator_df)
    empty_cols = indicator_df.any()
    empty_cols = empty_cols[empty_cols == False]
    indicator_df.drop(columns=empty_cols.index, inplace=True)
    return indicator_df


def split_timestamps_into_vars(in_df, temp_resolution):
    time_col = get_datetime_column(in_df)
    rows = []

    def split_timestamps(df):
        if temp_resolution.lower() == "monthly" or temp_resolution.lower() == "weekly":
            row_dict = {"index": df, "year": df.year, "month": df.month}
        elif temp_resolution.lower() == "daily":
            row_dict = {"index": df, "year": df.year, "month": df.month, "weekday": df.weekday()}
        else:  # Hourly
            row_dict = {"index": df, "year": df.year, "month": df.month, "weekday": df.weekday(), "hour": df.hour}
        rows.append(row_dict)

    if time_col == "index":
        in_df.index.to_series().apply(split_timestamps)
    else:
        in_df[time_col].apply(split_timestamps)
    return pd.DataFrame.from_records(rows, index="index")


def plot_multypoly_polygons(multipolygon):
    fig, ax = plt.subplots()
    cmap = plt.get_cmap('tab20').colors
    for i, poly in enumerate(list(multipolygon)):
        gpd.GeoSeries(poly).plot(ax=ax, color=cmap[i % len(cmap)], edgecolor="black", linewidth=0.8)
    plt.axis('tight')
    plt.show()


def mean_municipality_con_pr_month(municipality_df):
    municipality_df.drop(columns=["MeasurementPoints"], inplace=True)
    df_mean_totalcon = municipality_df.groupby("MunicipalityNo").mean()
    df_mean_totalcon.reset_index(inplace=True)
    return df_mean_totalcon


def voronoi_station_weights(in_df, plot_results=False):
    """
    Computes the Voronoi partition of Denmark, represented by a multi-polygon, given the set of DMI weather stations.
    Each Voronoi cell represents the geographical area "covered" by one associated station. Note: the method
    "voronoi_regions_from_coords" does not treat the multi-polygon of Denmark as separate parts when cutting Voronoi
    cells.
    :param in_df:
        DataFrame that must have column 'stationId', which contains all stations that are to be used as seeds, as well
        as a Geometry column of points, where each point represents the longitude and latitude of each station.
    :param plot_results:
    :return:
    """
    electricity_zone = in_df.priceArea.iloc[0]
    gdf_municipalities = read_municipality_geo_data()
    gdf_municipalities.to_crs(crs="EPSG:3045",
                              inplace=True)  # https://web.archive.org/web/20200805022439/https://epsg.io/3045
    denmark_boundary = gdf_municipalities.geometry.unary_union

    station_coords = pd.concat([in_df.geometry.x, in_df.geometry.y], axis=1).to_numpy()
    poly_shapes, pts, poly_to_pt, unassigned_pts = voronoi_regions_from_coords(station_coords, denmark_boundary,
                                                                               accept_n_coord_duplicates=0,
                                                                               return_unassigned_points=True)
    if len(unassigned_pts) > 0:
        warnings.warn("Voronoi tesselation did not assign all points. Leftover points: " + str(unassigned_pts))

    if plot_results:
        fig, ax = subplot_for_map()
        plot_voronoi_polys_with_points_in_area(ax, denmark_boundary, poly_shapes, station_coords,
                                               poly_to_pt)
        plt.axis('tight')
        plt.title("Voronoi Diagram using {} Weather Stations as Seeds".format(electricity_zone))
        plt.savefig(PLOT_FOLDER + "voronoi_{}_stations.png".format(electricity_zone), dpi=300)
        plt.show()

    gdf_regions = gpd.read_file(DATA_FOLDER + "regioner.geojson")
    gdf_regions.to_crs(crs="EPSG:3045", inplace=True)
    gdf_regions = gdf_regions[gdf_regions.REGIONNAVN.isin(ZONE_TO_REGIONS[electricity_zone])]
    gdf_zone = gdf_regions.geometry.unary_union  # Multipolygon of either DK1 or DK2
    gdf_municipalities = gdf_municipalities[gdf_municipalities.geometry.within(gdf_zone)]

    df_municip = read_municipality_con()
    df_mean_totalcon = mean_municipality_con_pr_month(df_municip)
    df_mean_totalcon = df_mean_totalcon[df_mean_totalcon.MunicipalityNo.isin(gdf_municipalities.MunicipalityNo
                                                                             .unique())]
    df_mean_totalcon["new_totalCon"] = 0.
    df_mean_totalcon["stationId"] = 0

    gdf_municipalities = gdf_municipalities.groupby("MunicipalityNo").apply(lambda x: x.geometry.unary_union)

    if plot_results:
        ax = gpd.GeoSeries(gdf_municipalities).plot(color="green", edgecolor="white")
        x_lim = ax.get_xlim()
        y_lim = ax.get_ylim()
        gpd.GeoSeries(poly_shapes).plot(ax=ax, color="None", edgecolor="tab:orange")
        ax.scatter(station_coords[:, 0], station_coords[:, 1], c="black", s=10, marker="x")
        plt.xlim(x_lim)
        plt.ylim(y_lim)
        ax.tick_params(bottom=False, left=False, right=False, top=False, labelleft=False, labelbottom=False)
        ax.set_facecolor('tab:blue')
        plt.title("{} Voronoi Cells (Orange Edges) \n Superimposed onto Municipalities (White Edges)"
                  .format(electricity_zone))
        plt.savefig(PLOT_FOLDER + "{}_voronoi_vs_municipalities.png".format(electricity_zone), dpi=300)
        plt.show()

    municipality_to_totalcon = dict(zip(df_mean_totalcon.MunicipalityNo, df_mean_totalcon.TotalCon))
    for i in range(len(poly_shapes)):
        share_of_consumption = 0
        for index, row in gdf_municipalities.iteritems():
            area_of_intersect = row.intersection(poly_shapes[i]).area
            municip_area = row.area
            share_of_consumption += (area_of_intersect / municip_area) * municipality_to_totalcon[index]
        stations = poly_to_pt[i]
        share_of_consumption /= len(stations)  # some Voronoi cells might contain more then one seed (station)
        for station in stations:
            df_mean_totalcon.at[station, "new_totalCon"] = share_of_consumption
            df_mean_totalcon.at[station, "stationId"] = in_df.iloc[[station]]["stationId"]
    df_mean_totalcon = df_mean_totalcon[df_mean_totalcon.stationId != 0]
    df_mean_totalcon.TotalCon = df_mean_totalcon.new_totalCon
    df_mean_totalcon.drop(columns=["MunicipalityNo", "new_totalCon"], inplace=True)
    df_mean_totalcon.TotalCon /= df_mean_totalcon.TotalCon.sum()

    return df_mean_totalcon


def mean_totcon_pr_station(param_df, consumption_as_ratio=False, station_municip_corrs=None):
    """
    Returns the mean monthly electricity consumption attributed to each weather station. Each station is located in a
    municipality, so if a municipality only contains a single station, then all of the monthly consumption will be
    attributed to that station. If a municipality contains more than one station, then the former's consumption is
    either uniformly divided among the stations, or, if "station_municip_corrs" != None, the correlation between the
    monthly summed/averaged observations of each station and the monthly electricity consumption of the municipality
    will determine the share of electricity consumption attributed to that station.
    :param consumption_as_ratio: optional, default False
        If True, divide the mean consumption of each municipality by the total mean consumption of all municipalities
    :param param_df:
        A DataFrame that contains a "MunicipalityNo" column. Is merged with the main municipality consumption DataFrame,
        whereupon the TotalCon cell in each row is divided by the number of times the municipality in said row
        occurs in the merged DataFrame. The consumption of a municipality is distributed uniformly over all rows in
        which it occurs (See 'subdivide_pr_municipality')
    :param station_municip_corrs: optional, default None
        A DataFrame with a multilevel index 'MunicipalityNo', 'stationId', where each row corresponds to the correlation
        between the monthly average/summed observations of the weather station with ID 'stationId' and the monthly
        electricity consumption of the municipality with number 'MunicipalityNo'. These correlations are then used to
        distribute the consumption of a municipality over all rows in which it occurs according to the 'stationId's of
        the rows. The correlations are normalized to sum to 1.
    :return:
        DataFrame
    """
    df_municip = read_municipality_con()
    df_mean_totalcon = mean_municipality_con_pr_month(df_municip)

    def subdivide_pr_municipality(df_municip_group):
        if station_municip_corrs:
            correlations = df_municip_group.apply(lambda x: station_municip_corrs[x.MunicipalityNo, x.stationId],
                                                  axis="columns")
            correlations /= correlations.sum()
            df_municip_group.TotalCon *= correlations
        else:
            df_municip_group.TotalCon /= len(df_municip_group)
        return df_municip_group

    electricity_zone = param_df.priceArea.iloc[0]
    gdf_regions = gpd.read_file(DATA_FOLDER + "regioner.geojson")
    gdf_regions = gdf_regions[gdf_regions.REGIONNAVN.isin(ZONE_TO_REGIONS[electricity_zone])]
    gdf_zone = gdf_regions.geometry.unary_union  # Multipolygon of either DK1 or DK2
    gdf_municipalities = read_municipality_geo_data()
    gdf_municipalities = gdf_municipalities[gdf_municipalities.geometry.within(gdf_zone)]
    df_mean_totalcon = df_mean_totalcon[df_mean_totalcon.MunicipalityNo.isin(gdf_municipalities.MunicipalityNo
                                                                             .unique())]
    df_mean_totalcon_pr_station = df_mean_totalcon.merge(param_df, how='inner', on="MunicipalityNo")
    df_mean_totalcon_pr_station = df_mean_totalcon_pr_station.groupby("MunicipalityNo") \
        .apply(subdivide_pr_municipality)
    if consumption_as_ratio:
        df_mean_totalcon_pr_station.TotalCon /= df_mean_totalcon.TotalCon.sum()
    return df_mean_totalcon_pr_station


def station_municipality_correlation(in_df, station_df, retain_maximum_only=False):
    """
    Calculates the Pearson correlations between the monthly mean/summed observations of each weather station and the
    monthly electricity consumption of the municipality it is located it.
    :param in_df:
        DataFrame of observations of a single weather parameter at different stations. Must contain columns
        'parameterId', 'stationId' and value', as well as a datetime column.
    :param station_df:
        DataFrame containing all stations of 'in_df' and their associated municipality. Must contain columns
        'MunicipalityNo' and 'stationId'
    :param retain_maximum_only: optional, default False
        If True, for each municipality, set maximum station correlation to 1 and all others to 0
    :return:
        A dictionary of type (MunicipalityNo, stationId) -> Weather parameter/Electricity Consumption correlation
    """
    df_municip = read_municipality_con()
    df_merged = station_df[["stationId", "MunicipalityNo"]].merge(df_municip, how="inner", on="MunicipalityNo")
    param = in_df.parameterId.iloc[0]
    date_column = get_datetime_column(in_df)
    if param in ACCUMULATIVE_PARAMS:
        in_df_res = in_df.groupby("stationId").apply(lambda x: x.resample("MS", on=date_column).sum()  # MS=Month Start
                                                     .drop(columns="stationId"))
    else:
        in_df_res = in_df.groupby("stationId").apply(lambda x: x.resample("MS", on=date_column).mean()
                                                     .drop(columns="stationId"))
    in_df_res.reset_index(inplace=True)
    in_df_res.rename(columns={date_column: "HourUTC"}, inplace=True)
    df_merged_final = df_merged.merge(in_df_res, how="inner", on=["HourUTC", "stationId"])
    df_station_municip_corr = df_merged_final.groupby(["MunicipalityNo", "stationId"]).apply(lambda x:
                                                                                             x.TotalCon.corr(x.value))

    def retain_max(group_df):
        abs_corrs = group_df.abs()
        max_corr = abs_corrs.max()
        max_cond = abs_corrs == max_corr
        group_df.where(max_cond, 0.0, inplace=True)
        return group_df

    if retain_maximum_only:
        df_station_municip_corr = df_station_municip_corr.groupby("MunicipalityNo").apply(retain_max)

    return df_station_municip_corr.to_dict()


def weather_geo_avg(in_df, weight_type=None, interpolate="after", verbose=False):
    """
    Calculate geographical average of a given weather parameter.
    :param verbose: optional, default False
        Whether to print verbose output when interpolating the data
    :param interpolate:

    :param in_df:
        Time series DataFrame of a single weather parameter. Must contain columns 'parameterId', 'stationId', 'value'
        and a datetime column of any name.
    :param weight_type: optional, default None
        If 'uniform', distribute the share of total energy consumption of each municipality equally among its
        stations. If 'correlation', distribute the share of total energy consumption of each municipality among
        its stations according to each station's correlation with the energy consumption in the municipality.
    :return:
        The geographically averaged time series of weather observations. Series that has the name of the weather
        parameter and a datetime index.
    """
    param = in_df.parameterId.iloc[0]
    if weight_type is not None and weight_type not in ["uniform", "correlation", "voronoi"]:
        raise ValueError("'weight_type' must be one of ['uniform', 'correlation', 'voronoi'] or None")
    elif interpolate.lower() not in ["before", "after"]:
        raise ValueError("'interpolate' must be one of ['before', 'after']")

    if interpolate.lower() == "before":
        in_df = interpolate_missing_timestamps(in_df, method="spatial", verbose=verbose)
    if get_datetime_column(in_df) == "index":
        in_df.reset_index(inplace=True)

    if weight_type is not None:
        in_df = in_df.copy(deep=True)
        df_stations = import_station_dataframe(DATA_FOLDER + "dmi_stations.json", in_df)
        gdf_municipalities = gpd.read_file(DATA_FOLDER + "kommuner.geojson")  # source: https://github.com/ok-dk/dagi
        gdf_municipalities.to_crs(crs="EPSG:3045", inplace=True)
        gdf_station = gpd.GeoDataFrame(df_stations[["name", "stationId", "priceArea"]],
                                       geometry=gpd.points_from_xy(df_stations.Longitude, df_stations.Latitude),
                                       crs="EPSG:4326")
        gdf_station.to_crs(crs="EPSG:3045", inplace=True)
        gdf_joined = gpd.sjoin(gdf_station, gdf_municipalities, how='left')
        gdf_joined.dropna(inplace=True)  # drop stations that are not inside any municipality (e.g., a lighthouse)
        gdf_joined.drop(columns=["index_right"], inplace=True)
        gdf_joined["KOMKODE"] = gdf_joined["KOMKODE"].astype(int)
        gdf_joined.rename(columns={"KOMKODE": "MunicipalityNo"}, inplace=True)
        if weight_type.lower() == "uniform":
            weight_df = mean_totcon_pr_station(consumption_as_ratio=True, param_df=gdf_joined)
        elif weight_type.lower() == "correlation":
            municip_station_to_corr = station_municipality_correlation(in_df, gdf_joined)
            weight_df = mean_totcon_pr_station(consumption_as_ratio=True, param_df=gdf_joined,
                                               station_municip_corrs=municip_station_to_corr)
        else:  # weight_type == "voronoi"
            weight_df = voronoi_station_weights(gdf_joined, plot_results=False)
        station_id_to_weight = {}
        for row in weight_df.itertuples():
            station_id_to_weight[row.stationId] = row.TotalCon
        in_df["weight"] = in_df.stationId.map(station_id_to_weight)
        if interpolate.lower() == "after":                          # re-adjust weights if stations have missing
            per_timegroup_sum = in_df.groupby("time").weight.sum()  # observations for certain timestamps
            timestamp_to_sum = per_timegroup_sum.to_dict()
            timegroup_sum_series = in_df.time.map(timestamp_to_sum)
            in_df["weight"] /= timegroup_sum_series
        geo_avg_df = (in_df.weight * in_df.value).groupby(in_df.time).sum()
        del in_df
    else:
        geo_avg_df = in_df.groupby("time").value.mean()
    geo_avg_df.rename(param, inplace=True)
    geo_avg_df.index.rename("HourUTC", inplace=True)
    if interpolate.lower() == "after":
        geo_avg_df = interpolate_missing_timestamps(geo_avg_df, verbose=verbose)
    return geo_avg_df


def get_logger(file_name, logger_name):
    formatter = logging.Formatter("%(asctime)s %(levelname)s | %(message)s")
    file_handler = logging.FileHandler(file_name)
    console_handler = logging.StreamHandler()
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.INFO)
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    return logger


def remove_logger(logger):
    logger.handlers = []


def degree_days(type_, geo_avg_type=None):
    """
    Calculates degree days at a daily time resolution in the two electricity zone DK1 and DK2. Base temperature is set
    to 17°C.
    :param type_:
        The degree day type. Must be either "heating" or "cooling".
    :return:
         Dictionary of type electricity zone -> degree day DataFrame at a daily time resolution
    """
    _df_temp = read_weather_data(DATA_FOLDER + "temp_cleaned.csv")
    df_stations = pd.read_csv(DATA_FOLDER + "dmi_stations_processed.csv")
    dd_dict = {}
    base_temp = 17
    for zone in ["DK1", "DK2"]:
        zone_df = _df_temp[_df_temp.stationId.isin(df_stations[df_stations.priceArea == zone].stationId)]
        geo_avg_df = weather_geo_avg(zone_df, weight_type=geo_avg_type)
        daily_geo_avg_df = geo_avg_df.resample("D").mean()
        if type_.lower() == "heating":
            res_daily_geo_avg_df = base_temp - daily_geo_avg_df
        elif type_.lower() == "cooling":
            res_daily_geo_avg_df = daily_geo_avg_df - base_temp
        else:
            raise ValueError("Degree day type parameter must be one of {'heating', 'cooling'}")
        zero_cond = res_daily_geo_avg_df >= 0
        res_daily_geo_avg_df.where(zero_cond, 0, inplace=True)
        dd_dict[zone] = res_daily_geo_avg_df
    return dd_dict


def arima(y, non_seasonal=None, seasonal=None, verbose=False, data_title=None, residual_plot=False,
          normalize_by_workdays=False, exog_vars=None, target_resolution=None, plot_error_pr_month=False):
    """
    Fits an ARIMA model based on the given orders and plots the fitted results + residual plot if desired.
    If no orders are given, auto_arima will try to automatically identify a good model and will try to include
    seasonality. Assumes that y has a datetime index. Returns the fitted ARIMA model
    :param y:
        The time series
    :param non_seasonal: optional
        The seasonal orders to include
    :param seasonal: optional
        The non-seasonal orders to include
    :param verbose:
    :param data_title:
    :param residual_plot:
    :param normalize_by_workdays:
    :param exog_vars:
    :return:
    """
    if normalize_by_workdays:
        y = divide_by_workdays(y)
    if seasonal is None and non_seasonal is not None:
        seasonal = [0, 0, 0, 0]
    X_train, y_train, X_test, y_test = train_test_split(y, TRAIN_SIZE, split_based_on=target_resolution)
    train_size = len(X_train)
    test_size = len(y_test)
    if non_seasonal is None and seasonal is None:
        arima_model = pm.auto_arima(y, seasonal=True, m=12, approximation=False, out_of_sample_size=test_size,
                                    scoring="mae", exogenous=exog_vars)
        y_pred_test = arima_model.oob_preds_
    else:
        arima_model = pm.ARIMA(non_seasonal, seasonal, out_of_sample_size=test_size, scoring="mae")
        arima_model.fit(y, exogenous=exog_vars)
        y_pred_test = arima_model.oob_preds_
    train_offset = (arima_model.seasonal_order[1] * arima_model.seasonal_order[-1]) + arima_model.order[1]
    y_pred_train = arima_model.predict_in_sample(start=train_offset, end=train_size - 1, exogenous=exog_vars)
    if normalize_by_workdays:
        y = divide_by_workdays(y, reverse=True)
        y_pred_train = divide_by_workdays(pd.Series(data=y_pred_train, index=y.index[train_offset:train_size]),
                                          reverse=True)
        y_pred_test = divide_by_workdays(pd.Series(data=y_pred_test, index=y.index[train_size:]), reverse=True)
        y_train = divide_by_workdays(y_train, reverse=True)
        y_test = divide_by_workdays(y_test, reverse=True)
    y_train = y_train[train_offset:]
    if target_resolution is not None:
        y_pred_train = pd.Series(y_pred_train, index=y_train.index)
        y_pred_train = y_pred_train.resample(RESOLUTION_TO_LETTER[target_resolution.lower()]).sum()
        y_pred_test = pd.Series(y_pred_test, index=y_test.index)
        y_pred_test = y_pred_test.resample(RESOLUTION_TO_LETTER[target_resolution.lower()]).sum()
        y_train = y_train.resample(RESOLUTION_TO_LETTER[target_resolution.lower()]).sum()
        y_test = y_test.resample(RESOLUTION_TO_LETTER[target_resolution.lower()]).sum()
    if verbose:
        parent_log_folder = log_folder
        set_log_folder(log_folder + data_title + "/")
        logger = get_logger(log_folder + data_title, data_title)
        orders_string = str(arima_model.order) + str(arima_model.seasonal_order)
        train_mae = mean_absolute_error(y_train, y_pred_train)
        train_mape = mean_abs_percentage_error(y_train, y_pred_train)
        test_mae = mean_absolute_error(y_test, y_pred_test)
        test_mape = mean_abs_percentage_error(y_test, y_pred_test)
        arima_model.mape_train = train_mape
        arima_model.mape_test = test_mape
        arima_model.mae_train = train_mae
        arima_model.mae_test = test_mae
        arima_model.y_pred_train = y_pred_train
        arima_model.y_pred_test = y_pred_test
        logger.info("ARIMA{} {} MAE:  Train: {} | Test:{}".format(orders_string, data_title, train_mae, test_mae))
        logger.info("ARIMA{} {} MAPE:  Train: {} | Test:{}".format(orders_string, data_title, train_mape, test_mape))
        logger.info("\n" + str(arima_model.summary()))
        remove_logger(logger)
        plt.plot_date(y_train.index, y_train, c='blue', linestyle='solid', marker='None')
        plt.plot_date(y_test.index, y_test, c='green', linestyle='solid', marker='None')
        plt.plot_date(y_train.index, y_pred_train, c='red', linestyle="solid", marker='None')
        plt.plot_date(y_test.index, y_pred_test, c='red', linestyle="solid", marker='None')
        plt.title("ARIMA{} {} Predictions".format(orders_string, data_title), y=1.04)
        plt.xlabel("time")
        plt.ylabel("MWh")
        plt.legend(["Train", "Test", "Prediction"])
        plt.savefig(log_folder + data_title + ".png", dpi=200, bbox_inches="tight")
        plt.show()
        if residual_plot:
            plot_residuals(None, pd.concat((y_train, y_test)), np.concatenate((y_pred_train, y_pred_test), axis=None),
                           data_title)
        if plot_error_pr_month:
            plot_average_error_per_month(y_test, y_pred_test, y_test.index, data_title + " Validation")
        set_log_folder(parent_log_folder)
    return arima_model


class SVDPLS(_PLS):
    def __init__(self, n_components=2, scale=True, deflation_mode="regression",
                 mode="A", algorithm="nipals", norm_y_weights=False,
                 max_iter=500, tol=1e-06, copy=True):
        super().__init__(n_components=n_components, scale=scale, deflation_mode=deflation_mode,
                         mode=mode, algorithm=algorithm, norm_y_weights=norm_y_weights,
                         max_iter=max_iter, tol=tol, copy=copy)


def pls_dim_reduction(X_df, y, n_components, target_resolution=None, return_coefs=False):
    pls_reg = SVDPLS(algorithm="svd", n_components=n_components)
    if y.name is None:
        y = y.rename("y")
    df = X_df.join(y, how="inner")
    df.rename(columns={df.columns[0]: "lag_0"}, inplace=True)
    X_train, y_train, X_test, y_test = train_test_split(df, TRAIN_SIZE, split_based_on=target_resolution)
    pls_reg.fit(X_train, y_train)
    if return_coefs:
        return pls_reg.transform(X_df), pls_reg.coef_
    return pls_reg.transform(X_df)


def pca(data, target_explained_var, return_basis_vecs=False):
    """
    Applies Principal Component Analysis (PCA) based dimensionality reduction to 'data'. This PCA method uses singular
    value decomposition to find principal components.
    :param data:
        DataFrame or Numpy array of the data to be transformed
    :param target_explained_var:
        Either the amount of principal components to use in the dimensionality reduction if integer, or the amount of
        variance to retain in the transformed data if in [0, 1[ and type = float.
    :param return_basis_vecs: optional, default False
        If True, return principal directions found via the PCA.
    :return:
    """
    pca_obj = PCA(whiten=True, n_components=target_explained_var,
                  svd_solver="full")
    columns = data.columns
    data_reduced = pca_obj.fit_transform(data)
    if return_basis_vecs:
        explained_var_pr_comp = pca_obj.explained_variance_ratio_.reshape(-1, 1)
        comp_eig_vecs = pca_obj.components_
        mat = np.concatenate((explained_var_pr_comp, comp_eig_vecs), axis=1)
        df = pd.DataFrame(data=mat, columns=np.concatenate((["explained_variance"], columns), axis=None))
        df.index.rename("Component", inplace=True)
        return data_reduced, df
    return data_reduced


def read_all_weather_dfs():
    df_radia = read_weather_data(DATA_FOLDER + "radia_cleaned.csv")
    df_temp = read_weather_data(DATA_FOLDER + "temp_cleaned.csv")
    df_precip = read_weather_data(DATA_FOLDER + "precip_cleaned.csv")
    df_humidity = read_weather_data(DATA_FOLDER + "humid_cleaned.csv")
    df_sun = read_weather_data(DATA_FOLDER + "sun_cleaned.csv")
    df_wind = read_weather_data(DATA_FOLDER + "wind_cleaned.csv")
    df_temp_grass = read_weather_data(DATA_FOLDER + "temp_grass_cleaned.csv")
    df_temp_soil = read_weather_data(DATA_FOLDER + "temp_soil_cleaned.csv")
    df_leav_humid = read_weather_data(DATA_FOLDER + "leav_humid_cleaned.csv")
    df_pressure = read_weather_data(DATA_FOLDER + "pressure_cleaned.csv")
    df_visibility = read_weather_data(DATA_FOLDER + "visibility_cleaned.csv")
    # df_snow = read_weather_data(DATA_FOLDER + "snow_depth_cleaned.csv")

    weather_dfs = [(df_radia, "radia_glob_past1h"), (df_temp, "temp_mean_past1h"), (df_precip, "precip_past1h"),
                   (df_humidity, "humidity_past1h"), (df_sun, "sun_last1h_glob"), (df_wind, "wind_speed_past1h"),
                   (df_temp_grass, "temp_grass_mean_past1h"), (df_temp_soil, "temp_soil_mean_past1h"),
                   (df_leav_humid, "leav_hum_dur_past1h"), (df_pressure, "pressure"), (df_visibility, "visibility")]
    # (df_snow, "snow_depth_man")]

    return [tup for tup in weather_dfs if tup[1] in INTERESTING_PARAMS]


def plot_el_vs_vars(include_boilers, resolution):
    """
    Plot electricity consumption vs each weather parameter for each electricity zone DK1 and DK2 seperately.
    :param include_boilers:
        If True, include the electricity consumed by electric boilers in the consumption.
    :param resolution:
        The resolution at which to compare the two variables. Must be one of "Hourly", "Daily", "Weekly" and "Monthly"
    :return:
    """
    df_el = import_el_data(EL_CONSUMP_FILE, include_boilers)
    price_area_to_el_df = {"DK1": df_el[df_el.PriceArea == "DK1"],
                           "DK2": df_el[df_el.PriceArea == "DK2"]}
    price_area_to_netcon = {}
    for zone, df in price_area_to_el_df.items():
        price_area_to_netcon[zone] = pd.Series(data=df.NetCon.values, index=df.HourUTC)
    dmi_df = import_dmi_data(DMI_FILE)
    df_stations = import_station_dataframe("../data/dmi_stations.json", dmi_df)
    param_df_list = read_all_weather_dfs()
    price_areas = ["DK1", "DK2"]
    for price_area in price_areas:
        df_el_curr = price_area_to_netcon[price_area]
        if resolution.lower() == "hourly":
            df_el_res = df_el_curr
        else:
            df_el_res = df_el_curr.resample(RESOLUTION_TO_LETTER[resolution.lower()]).sum()
        for df, param in param_df_list:
            df_curr = df[df.stationId.isin(df_stations[df_stations.priceArea == price_area].stationId)]
            df_curr_geo_avg = df_curr.groupby("time").value.mean()
            if resolution.lower() == "hourly":
                df_resampled = df_curr_geo_avg
            else:
                if param in ACCUMULATIVE_PARAMS:
                    df_resampled = df_curr_geo_avg.resample(RESOLUTION_TO_LETTER[resolution.lower()]).sum()
                else:
                    df_resampled = df_curr_geo_avg.resample(RESOLUTION_TO_LETTER[resolution.lower()]).mean()
            common_index = df_resampled.index.intersection(df_el_res.index)
            plt.scatter(df_resampled[df_resampled.index.isin(common_index)],
                        df_el_res[df_el_res.index.isin(common_index)])
            if not include_boilers:
                plt.title("{} {} vs {} NetCon in Price Area {} (Boilers Excluded)".format(resolution, param, resolution,
                                                                                          price_area), y=1.04)
            else:
                plt.title("{} {} vs {} NetCon in Price Area {}".format(resolution, param, resolution, price_area))
            plt.xlabel("{}".format(param))
            plt.ylabel("NetCon")
            plt.savefig(log_folder + "{} {} vs {} NetCon in Price Area {}".format(resolution, param, resolution,
                                                                                  price_area), dpi=200,
                        bbox_inches="tight")
            plt.show()


# Source: Mette Gamst
def __calculate_danish_easter(year):
    # https://da.wikipedia.org/wiki/P%C3%A5ske
    a = year % 19
    b = floor(year / 100)
    c = year % 100
    d = floor(b / 4)
    e = b % 4
    f = floor((b + 8) / 25)
    g = floor((b - f + 1) / 3)
    h = (19 * a + b - d - g + 15) % 30
    i = floor(c / 4)
    k = c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = floor((a + 11 * h + 22 * l) / 451)
    n = floor((h + l - 7 * m + 114) / 31)
    p = (h + l - 7 * m + 114) % 31 + 1
    return datetime(year, n, p)


# Source: Mette Gamst
def __danish_holidays(year):
    easterSunday = __calculate_danish_easter(year)
    easterThursday = easterSunday - timedelta(days=3)
    easterFriday = easterSunday - timedelta(days=2)
    easterMonday = easterSunday + timedelta(days=1)
    # https://da.wikipedia.org/wiki/Store_bededag
    greatPrayerDay = easterSunday + timedelta(days=26)
    # https://da.wikipedia.org/wiki/Kristi_himmelfartsdag
    ascensionDay = easterSunday + timedelta(39)
    # https://da.wikipedia.org/wiki/Pinse
    penteCostSunday = easterSunday + timedelta(days=49)
    penteCostMonday = easterSunday + timedelta(days=50)
    first_jan = datetime(year, 1, 1)
    christmas = datetime(year, 12, 24)
    christmas1 = datetime(year, 12, 25)
    christmas2 = datetime(year, 12, 26)
    christmas3 = datetime(year, 12, 27)
    christmas4 = datetime(year, 12, 28)
    christmas5 = datetime(year, 12, 29)
    christmas6 = datetime(year, 12, 30)
    newyears = datetime(year, 12, 31)
    return [easterSunday, easterThursday, easterFriday, easterMonday, greatPrayerDay, ascensionDay, penteCostSunday,
            penteCostMonday, first_jan, christmas, christmas1, christmas2, christmas3, christmas4, christmas5,
            christmas6, newyears]


def holiday_indicators(in_df):
    time_column = get_datetime_column(in_df)
    date_series = in_df.index if time_column == "index" else in_df[time_column]
    first_year = date_series[0].year
    last_year = date_series[-1].year
    holidays = [date for year in range(first_year, last_year + 1) for date in __danish_holidays(year)]
    holiday_dict = Counter(holidays)
    return date_series.map(holiday_dict)


def divide_by_workdays(y, reverse=False):
    """
    Divides y by the number of workdays in each month.
    :param y:
        The time series DataFrame to be normalized. Must have a datetime index with a monthly time resolution.
    :param reverse: optional, default
        If True, calculate the reserve operation, i.e. multiply by the number of workdays.
    :return:
    """
    workdays = []
    if y.index.freqstr not in ["M", "MS"]:
        raise ValueError("Index of input Series must be of type datetime in monthly resolution")
    current_year = 0
    holidays = []
    for date in y.index:
        year = date.year
        if year != current_year:
            holidays = __danish_holidays(year)
            current_year = year
        num_workdays = networkdays(date - relativedelta(months=1, day=1), date, holidays)
        workdays.append(num_workdays)
    if reverse:
        return y * workdays
    else:
        return y / workdays


def plot_average_error_per_month(y_true, y_pred, datetimes, model_name, save_plot=True):
    """
    Plots a bar plot of the MAE for each month.
    Assumes that y_true and y_pred are given at a monthly time resolution.
    :param y_true:
    :param y_pred:
    :param datetimes:
    :param model_name:
    :param save_plot:
    :return:
    """
    month_names = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
                   "November", "December"]
    errors = np.abs(np.array(y_true).flatten() - np.array(y_pred).flatten())
    months = datetimes.map(lambda x: x.month_name()).to_numpy()
    monthly_errors = pd.Series(errors).groupby(months).mean()
    monthly_errors = monthly_errors.reindex(month_names)
    monthly_errors.plot.bar(title=f"{model_name} MAE/Month")
    plt.ylabel("MWh")
    if save_plot:
        plt.savefig(f"{log_folder}validation_MAE_pr_Month{datetime.now()}.png", dpi=200, bbox_inches="tight")
    plt.show()


if __name__ == '__main__':
    pass