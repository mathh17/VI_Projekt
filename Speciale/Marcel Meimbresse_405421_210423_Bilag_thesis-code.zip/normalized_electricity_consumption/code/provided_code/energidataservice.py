from requests import get
from pandas import DataFrame, to_datetime

def __read_market_data(date_start, date_end):    
    url = """https://api.energidataservice.dk/datastore_search_sql?sql=SELECT * FROM "electricitybalance" WHERE "HourUTC" >= '""" + date_start.strftime("%Y-%m-%dT%H:%M:%S") + """' AND "HourUTC" < '""" + date_end.strftime("%Y-%m-%dT%H:%M:%S") + """' """
    api_call = get(url)
    df = DataFrame(api_call.json()["result"]["records"]).drop(columns = ["_id", "_full_text"])
    df['HourUTC'] =  to_datetime(df['HourUTC'], format='%Y-%m-%dT%H:%M:%S+00:00')