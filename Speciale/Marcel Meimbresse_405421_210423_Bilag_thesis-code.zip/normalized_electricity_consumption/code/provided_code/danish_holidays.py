from datetime import datetime, timedelta

def __calculateDanishEaster(year):
    #https://da.wikipedia.org/wiki/P%C3%A5ske
    a = year % 19
    b = floor(year / 100)
    c = year % 100
    d = floor( b / 4)
    e = b % 4
    f = floor((b + 8) / 25)
    g = floor((b - f + 1) / 3)
    h = (19 * a + b - d - g + 15) % 30
    i = floor(c / 4)
    k = c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = floor((a + 11 * h + 22 * l) / 451)
    n = floor((h + l - 7 * m + 114) / 31)
    p = (h + l - 7 * m + 114) % 31 + 1  
    return datetime(year, n, p)
	
	

def __danishHolidays(year):
    easterSunday = __calculateDanishEaster(year)
    easterThursday = easterSunday - timedelta(days = 3)
    easterFriday = easterSunday - timedelta(days = 2)
    easterMonday = easterSunday + timedelta(days = 1)
    #https://da.wikipedia.org/wiki/Store_bededag
    greatPrayerDay = easterSunday + timedelta(days = 26) 
    #https://da.wikipedia.org/wiki/Kristi_himmelfartsdag
    ascensionDay = easterSunday + timedelta(39)
    #https://da.wikipedia.org/wiki/Pinse
    penteCostSunday = easterSunday + timedelta(days = 49)
    penteCostMonday = easterSunday + timedelta(days = 50)
    first_jan = datetime(year, 1, 1)
    christmas = datetime(year, 12, 24)
    christmas1 = datetime(year, 12, 25)
    christmas2 = datetime(year, 12, 26)
    christmas3 = datetime(year, 12, 27)
    christmas4 = datetime(year, 12, 28)
    christmas5 = datetime(year, 12, 29)
    christmas6 = datetime(year, 12, 30)
    newyears = datetime(year, 12, 31)