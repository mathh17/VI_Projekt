from requests import get
from pandas import to_datetime, DataFrame

def __datetime_to_unixtime(dt):
    '''Function converting a datetime objects to a Unix microsecond string'''
    return str(int(to_datetime(dt).value*10**-3))
 
def __extract_parameter_timeseries(stationId, parameterId, date_start, date_end, api_key):    
    url = 'https://dmigw.govcloud.dk/metObs/v1/observation' # url for the current api version    
    params = {'api-key' : api_key,
              'from' : __datetime_to_unixtime(date_start),
              'to' : __datetime_to_unixtime(date_end),
              'stationId' : stationId, 
              'parameterId' : parameterId,          
              'limit' : '10000000',
              }
    
r = get(url, params=params) 
df = DataFrame(r.json()) 
df['time'] = to_datetime(df['timeObserved'], unit='us')    