import numpy as np
from scipy import stats, linalg
import scipy.sparse as sp
from sklearn.linear_model import LinearRegression as LinearRegression_sklearn
from sklearn.linear_model.base import _rescale_data
from sklearn.utils._joblib import Parallel, delayed
from sklearn.utils import check_X_y
from sklearn.utils.fixes import sparse_lsqr


# Equal to sklearn's LinearRegression class, but "fit" also calculates t and p values of coefficients
# These can be accessed via the attributes t and p, respectively. In addition, normalized coefficients
# are now saved in the attribute coef_normalized_ if the parameter "normalize" is set to True. By default,
# coefficients are de-normalized in "_set_intercept" after fitting the model.
# Calculation of t and p values based on https://gist.github.com/brentp/5355925
class LinearRegression(LinearRegression_sklearn):
    
    def __init__(self, *args, **kwargs):
        super(LinearRegression, self).__init__(*args, **kwargs)

    def fit(self, X, y, sample_weight=None):
        reg = self.fit_(X, y, sample_weight)
        df = y.shape[0] - X.shape[1] - self.fit_intercept  # degrees of freedom: #samples - #regressors - 1 (intercept)
        sse = np.sum((reg.predict(X) - y) ** 2, axis=0) / df  # sample variance
        precision_matrix = np.linalg.inv(np.dot(X.T, X))
        se = np.sqrt(np.diagonal(np.array(sse) * precision_matrix))  # std errors
        reg.t = reg.coef_ / se
        reg.p = 2 * (1 - stats.t.cdf(np.abs(reg.t), df))  # two-tailed test
        return reg

    # Modified version of sklearn's fit
    def fit_(self, X, y, sample_weight=None):
        """
        Fit linear model.
        Parameters
        ----------
        X : array-like or sparse matrix, shape (n_samples, n_features)
            Training data
        y : array_like, shape (n_samples, n_targets)
            Target values. Will be cast to X's dtype if necessary
        sample_weight : numpy array of shape [n_samples]
            Individual weights for each sample
            .. versionadded:: 0.17
               parameter *sample_weight* support to LinearRegression.
        Returns
        -------
        self : returns an instance of self.
        """

        n_jobs_ = self.n_jobs
        X, y = check_X_y(X, y, accept_sparse=['csr', 'csc', 'coo'],
                         y_numeric=True, multi_output=True)

        if sample_weight is not None and np.atleast_1d(sample_weight).ndim > 1:
            raise ValueError("Sample weights must be 1D array or scalar")

        X, y, X_offset, y_offset, X_scale = self._preprocess_data(
            X, y, fit_intercept=self.fit_intercept, normalize=self.normalize,
            copy=self.copy_X, sample_weight=sample_weight)

        if sample_weight is not None:
            # Sample weight can be implemented via a simple rescaling.
            X, y = _rescale_data(X, y, sample_weight)

        if sp.issparse(X):
            if y.ndim < 2:
                out = sparse_lsqr(X, y)
                self.coef_ = out[0]
                self._residues = out[3]
            else:
                # sparse_lstsq cannot handle y with shape (M, K)
                outs = Parallel(n_jobs=n_jobs_)(
                    delayed(sparse_lsqr)(X, y[:, j].ravel())
                    for j in range(y.shape[1]))
                self.coef_ = np.vstack([out[0] for out in outs])
                self._residues = np.vstack([out[3] for out in outs])
        else:
            self.coef_, self._residues, self.rank_, self.singular_ = \
                linalg.lstsq(X, y)
            self.coef_ = self.coef_.T

        if y.ndim == 1:
            self.coef_ = np.ravel(self.coef_)
        if self.normalize:
            self.coef_normalized_ = self.coef_
        self._set_intercept(X_offset, y_offset, X_scale)

        return self
