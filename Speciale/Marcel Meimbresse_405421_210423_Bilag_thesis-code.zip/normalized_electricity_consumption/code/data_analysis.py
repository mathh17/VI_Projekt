# -*- coding: utf-8 -*-
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import plotly.graph_objects as go
from project_constants import DMI_FILE, INTERESTING_PARAMS, DATA_FOLDER, PLOT_FOLDER
import gc
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
import geopandas as gpd

VERBOSE = False  # Whether to print verbose output and produce plots during the data cleaning process
FURTHER_ANALYSIS = False    # Whether to run the brief analysis on temperature data


def read_municipality_geo_data():
    gdf_municipalities = gpd.read_file(DATA_FOLDER + "kommuner.geojson")
    gdf_municipalities["KOMKODE"] = gdf_municipalities["KOMKODE"].astype(int)
    gdf_municipalities.rename(columns={"KOMKODE": "MunicipalityNo"}, inplace=True)
    gdf_municipalities = gdf_municipalities[gdf_municipalities.MunicipalityNo != 411]  # exclude Ertholmene archipelago
    return gdf_municipalities


def read_municipality_con():
    """
    :return: df
        Total MONTHLY electricity consumption per municipality in MWh, data from 2013-2020
    """
    df = pd.read_csv(DATA_FOLDER + "energinet_municipalities.csv")
    df['HourUTC'] = pd.to_datetime(df['Month'], format='%Y-%m-%d')
    df.drop(columns="Month", inplace=True)
    return df


def import_el_data(el_file, include_boiler_con=True):
    df_electricity = pd.read_csv(el_file)
    df_electricity['HourUTC'] = pd.to_datetime(df_electricity['HourUTC'], format='%Y-%m-%d %H:%M:%S')
    df_electricity.sort_values(by="HourUTC", inplace=True)
    if not include_boiler_con:
        nan_mask = df_electricity.ElectricBoilerCon.isna()          # replace NaN due to missing boiler consumption data
        orig_netcon = df_electricity.NetCon.copy()
        df_electricity.NetCon -= df_electricity.ElectricBoilerCon
        df_electricity.NetCon.where((nan_mask == False), orig_netcon, inplace=True)
    return df_electricity


def import_dmi_data(dmi_file):
    _df = pd.read_csv(dmi_file)
    _df['time'] = pd.to_datetime(_df['timeObserved'], unit='us')
    _df = _df[_df.stationId >= 5000]  # remove all Greenland stations
    replace_negative_precipitation(_df)
    replace_negative_snow(_df)
    return _df


def read_weather_data(file_name):
    _df = pd.read_csv(file_name)
    _df['time'] = pd.to_datetime(_df['time'], format='%Y-%m-%d %H:%M:%S')
    _df.drop(columns="timeObserved", inplace=True)
    _df.sort_values(by="time", inplace=True)
    return _df


# Replaces <0.1 mm rain with 0 mm. This is done in place
def replace_negative_precipitation(in_df):
    precip_cond = ((in_df.parameterId == "precip_past1h") & (in_df.value == -0.1)) == False
    in_df.value.where(precip_cond, 0.0, inplace=True)


# Replaces <0.5 cm snow with 0 cm. This is done in place
def replace_negative_snow(in_df):
    snow_cond = ((in_df.parameterId == "snow_depth_man") & (in_df.value == -1.0)) == False
    in_df.value.where(snow_cond, 0.0, inplace=True)


def df_list(main_df, interesting_params):
    list_ = []
    for param in interesting_params:
        param_df = main_df[main_df.parameterId == param].sort_values(by="value")
        list_.append(param_df)
    return list_


def plot_extreme_values(in_df, end, n=100):
    """
    Plots the top/bottom n values. Assumes that in_df is ordered in ascending order by value
    """
    param = in_df.parameterId.iloc[0]
    if end == "top":
        in_df.tail(n).plot.scatter(x="stationId", y="value", title="Top 100 {}".format(param))
    elif end == "bottom":
        in_df.head(n).plot.scatter(x="stationId", y="value", title="Bottom 100 {}".format(param))
    else:
        raise ValueError("parameter 'end' must be either 'top' or 'bottom' ")
    plt.show()


def count_extreme_station_values(in_df, end, n=100):
    if end == "top":
        return in_df.tail(n).groupby("stationId").count().sort_values(by="value", ascending=False)
    elif end == "bottom":
        return in_df.head(n).groupby("stationId").count().sort_values(by="value", ascending=False)
    else:
        raise ValueError("parameter 'end' must be either 'top' or 'bottom' ")


def import_station_dataframe(station_file, _dmi_df):

    def price_area(station_id):
        station = _df_stations[_df_stations.stationId == station_id]
        lon = station.Longitude.item()
        lat = station.Latitude.item()
        if (7.141113 <= lon <= 12.370605) and (56.231139 <= lat <= 58.106910) or \
           (7.360840 <= lon <= 10.986328) and (55.770394 <= lat <= 56.638106) or \
           (6.849976 <= lon <= 10.838013) and (54.463653 <= lat <= 55.856817) or \
           (10.327148 <= lon <= 10.980835) and (54.844990 <= lat <= 55.438363):
            return "DK1"
        else:
            return "DK2"

    _df_stations = pd.read_json(station_file)
    _df_stations = _df_stations[_df_stations.stationId.isin(_dmi_df.stationId.unique())]
    _df_stations["Longitude"] = _df_stations.location.apply(lambda x: x["longitude"])
    _df_stations["Latitude"] = _df_stations.location.apply(lambda x: x["latitude"])
    _df_stations["priceArea"] = _df_stations.stationId.apply(price_area)
    _df_stations.drop(columns=['_id', 'country', 'instrumentParameter', 'location', 'owner', 'regionId', 'status',
                               'timeCreated', 'timeOperationFrom', 'timeOperationTo', 'timeUpdated', 'timeValidFrom',
                               'timeValidTo', 'type', 'wmoCountryCode', 'wmoStationId'], inplace=True)
    return _df_stations


def plot_dmi_stations(in_df, error_stations_=None, save_figure=False):
    gdf_municipalities = gpd.read_file(DATA_FOLDER + "kommuner.geojson")
    df_stations_ = import_station_dataframe(DATA_FOLDER + "dmi_stations.json", in_df)
    if error_stations_ is not None:
        station_colors = list(map(lambda x: "red" if x in error_stations_ else "black", in_df.stationId.unique()))
    else:
        station_colors = "red"
    ax = gdf_municipalities.plot(color="green", edgecolor="lightgrey")
    ax.scatter(df_stations_.Longitude, df_stations_.Latitude, c=station_colors, s=8, marker="x")
    plt.axis("off")
    if save_figure:
        plt.savefig(PLOT_FOLDER + "muninipality_stations.png", dpi=200)
    plt.show()


def geo_plot_stations(in_df):
    hover_text = in_df.stationId.astype(str) + ": " + in_df.name
    stationColors = in_df.stationId.apply(lambda x: "red" if x in error_stations else "green")
    fig = go.Figure(data=go.Scattergeo(
        lon=in_df["Longitude"],
        lat=in_df["Latitude"],
        text=hover_text,
        mode='markers',
        marker_color=stationColors
    ))

    fig.update_geos(resolution=50)
    fig.update_layout(
        title=('DMI Weather Stations (Hover for Station ID and Location) <br>'
               + '<sub>Error Prone Stations Marked Red</sub>'),
        geo_scope='europe',
    )
    fig.show()


def geo_plot_by_price_area(in_df):
    hover_text = in_df.stationId.astype(str) + ": " + in_df.name
    area_color = in_df.priceArea.apply(lambda x: "red" if x == "DK1" else "blue")
    fig = go.Figure(data=go.Scattergeo(
        lon=in_df["Longitude"],
        lat=in_df["Latitude"],
        text=hover_text,
        mode='markers',
        marker_color=area_color
    ))

    fig.update_geos(resolution=50)
    fig.update_layout(
        title=('DMI Stations split by Electricity Pricing Area <br>' +
               '<sub>(DK1 = red, DK2 = blue)</sub>'),
        geo_scope='europe',
    )
    fig.show()


def plot_values_by_time(in_df, extreme_value_dict, title=""):
    param = in_df.parameterId.iloc[0]
    low_bound = extreme_value_dict[param][0]
    up_bound = extreme_value_dict[param][1]
    fig, ax = plt.subplots()
    in_df.sort_values(by="time").plot.scatter(x="time", y="value", ax=ax, title="{} {}".format(param, title))
    ax.axhline(y=low_bound, c="r")
    ax.axhline(y=up_bound, c="r")
    plt.show()


def remove_out_of_bounds_vals(in_df, extreme_value_dict):
    extreme_cond = (in_df.value >= in_df.parameterId.map(lambda param: extreme_value_dict[param][0])) \
                   & (in_df.value <= in_df.parameterId.map(lambda param: extreme_value_dict[param][1]))
    in_df.value.where(extreme_cond, np.nan, inplace=True)


# Window size must be odd
def rolling_median_outlier_detect(in_df, window_size, thresh, verbose=False):
    rolling_med = in_df.rolling(window_size, min_periods=1, center=True, on="time").median().value
    outlier_series = (in_df.value - rolling_med).abs() < thresh
    if verbose:
        print("{}% of all data is kept".format((outlier_series.sum()/outlier_series.size) * 100))
    return outlier_series


def remove_outliers(in_df, param_dict, plot_outliers=False):
    _param = in_df.parameterId.iloc[0]
    neighborhood_size, k = param_dict[_param]
    outliers = rolling_median_outlier_detect(in_df, neighborhood_size, in_df.value.std() * k, plot_outliers)
    in_df["outlier_series"] = outliers
    if plot_outliers:
        in_df[in_df.outlier_series].plot.scatter(x="time", y="value", c="blue",
                                                 title="{}: Data with Outliers Removed".format(_param))
        plt.show()
        in_df[in_df.outlier_series == False].plot.scatter(x="time", y="value", c="red",
                                                          title="{}: Removed Outliers".format(_param))
        plt.show()
    in_df = in_df[in_df.outlier_series].drop(columns="outlier_series")
    return in_df


def save_cleaned_param_dfs(df_list_):
    file_name_dict = {"wind_speed_past1h": "wind_cleaned", "temp_mean_past1h": "temp_cleaned",
                      "humidity_past1h": "humid_cleaned", "precip_past1h": "precip_cleaned",
                      "radia_glob_past1h": "radia_cleaned", "sun_last1h_glob": "sun_cleaned",
                      "temp_grass_mean_past1h": "temp_grass_cleaned", "temp_soil_mean_past1h": 
                      "temp_soil_cleaned", "leav_hum_dur_past1h": "leav_humid_cleaned",
                      "pressure": "pressure_cleaned", "visibility": "visibility_cleaned",
                      "snow_depth_man": "snow_depth_cleaned"}
    for df in df_list_:
        param = df.parameterId.iloc[0]
        df.to_csv("{}{}.csv".format(DATA_FOLDER, file_name_dict[param]), index=False)


def param_idx(df_list_, param):
    for i in range(len(df_list_)):
        if dfs[i].parameterId.iloc[0] == param:
            return i
    raise ValueError("Unable to find the given parameter in Dataframe list")


# in_series must have a datetime index
def auto_corr_plot(in_series, param, partial=False):
    lags = min(len(in_series) // 4, 40)
    if partial:
        fig = plot_pacf(in_series, lags=lags, zero=False, title="{} Partial Autocorrelation".format(param))
    else:
        fig = plot_acf(in_series, lags=lags, zero=False, title="{} Autocorrelation".format(param))
    plt.xticks(np.arange(0, lags+1), rotation=-35)
    plt.xlabel("Time lag")
    plt.ylabel("Coef.")
    plt.grid(True)
    plt.show()
    return fig


if __name__ == '__main__':
    dmi_df = import_dmi_data(DMI_FILE)

    """Read in weather extremes recorded by DMI and remove all values outside these bounds as a first measure to remove
     erronous measurements:"""

    extreme_temps_df = pd.read_csv("../data/absolut-højeste-og-laveste-temperatur-(°c).csv", sep=";")
    max_temp = extreme_temps_df['Højeste temperatur'].max()
    min_temp = extreme_temps_df['Laveste temperatur'].min()

    other_extremes_df = pd.read_csv("../data/dmi_ekstremer.csv")

    """###Determining Error Prone Stations"""

    dfs = df_list(dmi_df, INTERESTING_PARAMS)

    if VERBOSE:
        for df_ in dfs:
            plot_extreme_values(df_, "top")
            plot_extreme_values(df_, "bottom")


    """It is evident in the plots above that there are a few stations that account for a big portion of erroneous 
    measurements. Hence, it makes sense to discard the measurements of these stations for specific parameters. Let's
    identify which stations have the most erroneous measurements:
    """

    if VERBOSE:
        for df_ in dfs:
            _param = df_.parameterId.iloc[0]
            top_counts = count_extreme_station_values(df_, "top")
            bottom_counts = count_extreme_station_values(df_, "bottom")
            print("Top_counts of {}:\n".format(_param), top_counts)
            print("Bottom_counts of {}:\n".format(_param), bottom_counts)

    temp_error_stations = [6102, 6119, 6135]
    wind_error_stations = []
    humidity_error_stations = []
    sun_error_stations = []
    precip_error_stations = [5009]
    radia_error_stations = [6197]
    temp_grass_error_stations = [6065, 6135, 6197, 6102]
    temp_soil_error_stations = [6082, 6088]
    leav_humid_error_stations = [6082]
    pressure_error_stations = [6049, 6032]
    visibility_error_stations = [6184, 6123, 6156]
    snow_error_stations = [26450]
    
    error_stations = (temp_error_stations + wind_error_stations + humidity_error_stations + sun_error_stations +
                    precip_error_stations + radia_error_stations + temp_grass_error_stations + temp_soil_error_stations +
                    leav_humid_error_stations + pressure_error_stations + visibility_error_stations + snow_error_stations)
    
    error_station_dict = {"temp_mean_past1h": temp_error_stations, "wind_speed_past1h": wind_error_stations,
                      "humidity_past1h": humidity_error_stations,"precip_past1h": precip_error_stations,
                      "radia_glob_past1h": radia_error_stations, "sun_last1h_glob": sun_error_stations, 
                      "temp_grass_mean_past1h": temp_grass_error_stations, "temp_soil_mean_past1h":
                      temp_soil_error_stations, "leav_hum_dur_past1h": leav_humid_error_stations,
                      "pressure": pressure_error_stations, "visibility": visibility_error_stations,
                      "snow_depth_man": snow_error_stations}

    """### Geographic Analysis
    
    Plot the locations of the stations to get an intuition for why they might measure extreme values more often:
    """

    df_stations = import_station_dataframe("../data/dmi_stations.json", dmi_df)
    if VERBOSE:
        geo_plot_stations(df_stations)
        geo_plot_by_price_area(df_stations)

    # df_stations.drop(columns=["_id", "location", "regionId", "timeCreated", "timeUpdated",
    #                           "timeOperationFrom", "timeOperationTo", "timeValidTo",
    #                           "wmoCountryCode", "wmoStationId"], inplace=True)
    # df_stations.to_csv("df_stations_priceArea.csv", index=False)

    """###Raw Data Plots"""

    extreme_values_dict = {
        "temp_mean_past1h": (min_temp, max_temp),
        "wind_speed_past1h": (0., 39.5),
        "humidity_past1h": (1., 100.),
        "precip_past1h": (0., 60.),  # max: estimate based on definition of "dobbelt skybrud (>30mm regn/30 min.)"
        "radia_glob_past1h": (0., 1120.),  # estimate based on https://www.newport.com/t/introduction-to-solar-radiation
        "sun_last1h_glob": (0., 60.),
        "visibility": (0., 240000.), # estimate based on https://en.wikipedia.org/wiki/Visibility
        "leav_hum_dur_past1h": (0., 60.),
        "temp_soil_mean_past1h": (min_temp, max_temp), # estimate based on min, max air temperature
        "temp_grass_mean_past1h": (min_temp, max_temp), # estimate based on min, max air temperature
        "pressure": (870., 1085.), # estimate based on https://en.wikipedia.org/wiki/Atmospheric_pressure
        "snow_depth_man": (0., 135.) # estimate based on https://vejr.tv2.dk/2019-12-28-her-er-de-danske-vejrrekorder-fra-de-seneste-10-aar
    }

    if VERBOSE:
        for _df in dfs:
            plot_values_by_time(_df, extreme_values_dict, "Raw Data")

    """# Data Cleaning"""

    if VERBOSE:
        print("Number of NAN values by default:")
        print(dmi_df.isna().sum())    # no missing values out of the box

    remove_out_of_bounds_vals(dmi_df, extreme_values_dict)

    if VERBOSE:
        print("Number of NAN values that were out of bounds and replaced by NAN:")
        print(dmi_df.isna().sum())   # 2832 erroneous values

    del dfs
    gc.collect()
    dfs = df_list(dmi_df, INTERESTING_PARAMS)

    """###Further Determination of Error Prone Stations by Means of Out of Bounds Values

       We now use the introduced nan values to determine which stations had the most erroneous values. 
       Then we (manually) add these stations to the existing error station lists for the different parameters,
        if they have not been added already by the simple counting of extreme values done initially.
       """

    if VERBOSE:
        for i in range(len(dfs)):
            print(dfs[i][dfs[i].value.isna()].groupby("stationId").count().sort_values(by="time", ascending=False))

    for i in range(len(dfs)):
        _param = dfs[i].parameterId.iloc[0]
        param_error_stations = error_station_dict[_param]
        dfs[i].sort_values(by=["stationId", "time"], inplace=True)
        dfs[i] = dfs[i][dfs[i].stationId.isin(param_error_stations) == False]
        dfs[i] = dfs[i].groupby("stationId").apply(lambda x: x.interpolate(method='linear', limit_area='inside'))

    """Outlier Detection
    """

    # This dictionary describes the empirically chosen neighborhood size and removal threshold for each weather
    # parameter, where the threshold is the standard deviation of the param multiplied by an integer constant
    twosided_median_param_dict = {"wind_speed_past1h": (3, 1), "temp_mean_past1h": (17, 1),
                                  "humidity_past1h": (3, 1), "precip_past1h": (3, 8),
                                  "radia_glob_past1h": (7, 1), "sun_last1h_glob": (3, 2),
                                  "temp_grass_mean_past1h": (12, 1), "temp_soil_mean_past1h": (3, 1), 
                                  "leav_hum_dur_past1h": (3, 2), "pressure": (10, 1),
                                  "visibility": (3, 1.5), "snow_depth_man": (3, 3)}

    for i in range(len(dfs)):
        dfs[i] = remove_outliers(dfs[i], twosided_median_param_dict, VERBOSE)
        if VERBOSE:
            print("DataFrame of parameter {} has {} nan values".format(dfs[i].parameterId.iloc[0],
                                                                       dfs[i].value.isna().sum()))

    """###Cleaned Data Plots
    
    Checking the results of removing extreme values, error prone stations and outliers, as well as estimating removed
     values by interpolation:
    """

    if VERBOSE:
        for _df in dfs:
            plot_values_by_time(_df, extreme_values_dict, "Cleaned Data")

    save_cleaned_param_dfs(dfs)         # Data Cleaning is finished

    # Some stations do not have continuous data for the whole period
    temp_idx = param_idx(dfs, "temp_mean_past1h")
    if VERBOSE:
        print("Total number of observations of three different stations:")
        print(len(dfs[temp_idx][dfs[temp_idx].stationId == 6068].value.values))
        print(len(dfs[temp_idx][dfs[temp_idx].stationId == 6019].value.values))
        print(len(dfs[temp_idx][dfs[temp_idx].stationId == 6126].value.values))
        dfs[temp_idx][dfs[temp_idx].stationId == 6088].plot.scatter(x="time", y="value",
                                                      title="Temperature measurements of station 6088")
        plt.show()

    """# Further Analysis
    
    ###Averaging
    The following plot investigates to what extent taking the geographical average over the area DK1 flattens out 
    important extremes that may be valuable in forcasting models.
    """
    df_temp = dfs[temp_idx]
    df_temp_dk1 = df_temp[df_temp.stationId.isin(df_stations[df_stations.priceArea == "DK1"].stationId)]
    df_temp_dk2 = df_temp[df_temp.stationId.isin(df_stations[df_stations.priceArea == "DK2"].stationId)]
    if FURTHER_ANALYSIS:
        ax = df_temp_dk1.plot(x="time", y="value")
        df_temp_dk1.groupby("time").value.mean().plot(ax=ax, title="DK1 Geographical Average Temperature Superimposed "
                                                                   "Onto the Raw Temperature")
        plt.show()

        ax = df_temp_dk2.plot(x="time", y="value", legend=False)
        df_temp_dk2.groupby("time").value.mean().plot(ax=ax, title="DK2 Geographic Average Temperature Superimposed "
                                                                   "Onto the Raw Temperature")
        plt.show()

        """As evident in these plots, this is indeed the case, to a certain extent.
        
        Let's now investigate the impact of temporal averaging: In the following, we average the data over a time 
        period of 24 hours.
        """

        df_temp_dk1.set_index("time", drop=True, inplace=True) # Index dataFrame by time

        df_temp_dk1_day = df_temp_dk1.groupby("stationId").apply(lambda x: x.resample("D").value.mean())
        df_temp_dk1_day = df_temp_dk1_day.transpose()
        ax = df_temp_dk1.plot(y="value")
        df_temp_dk1_day.plot(title="DK1 Daily Average Temperature For each Station Superimposed Onto the Raw "
                                   "Temperature", c="tab:orange", legend=False, ax=ax)
        plt.show()

        df_temp_dk2.set_index("time", drop=True, inplace=True)
        df_temp_dk2_day = df_temp_dk2.groupby("stationId").apply(lambda x: x.resample("D").value.mean())
        df_temp_dk2_day = df_temp_dk2_day.transpose()
        ax = df_temp_dk2.plot(y="value", legend=False)
        df_temp_dk2_day.plot(title="DK2 Daily Average Temperature For each Station Superimposed Onto the Raw "
                                   "Temperature", c="tab:orange", legend=False, ax=ax)
        plt.show()

        """Now, we'll investigate the combined effect of temporal and spatial averaging, at a time resolution of 24 hours."""

        dk1_day_geo_avg_temp = df_temp_dk1_day.mean(axis=1)
        ax = df_temp_dk1.plot(y="value")
        dk1_day_geo_avg_temp.plot(title="DK1 Daily Geographic Average Temperature Superimposed Onto the Raw "
                                        "Temperature", ax=ax)
        plt.show()

        dk2_day_geo_avg_temp = df_temp_dk2_day.mean(axis=1)

        ax = df_temp_dk2.plot(y="value", legend=False)
        dk2_day_geo_avg_temp.plot(title="DK2 Daily Geographic Average Temperature Superimposed Onto the Raw "
                                        "Temperature", ax=ax)
        plt.show()
