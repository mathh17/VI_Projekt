# normalized_electricity_consumption

Master thesis project on the prediction of electricity consumption. 